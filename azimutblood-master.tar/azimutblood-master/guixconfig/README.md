# GUIX configuration folder

This folder contains all files necessary to generate the environment from GUIX
See : https://hpc.guix.info/ and https://guix.gnu.org/

* channels.scm : gets the commit number to get reproductible versions of the environment
* manifest.scm : gets the packages stored in GUIX
* my-pkgs.scm : gets the packges with reproductible versions that are not stored in GUIX
