#' Extraction relative abundances of state metaclusters in each type metaclusters by patients
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(CATALYST)
library(SingleCellExperiment)
library(tidyverse)

#' Read sce object with state metaclusters and type metaclusters stored in sce$type_55mk
message("Reading SCE object")
sce = readRDS("~/R_output/sce_objects/sce_tcellsfunc.RData")
message("Done\n")

#' Avoid scientific notation in extracted data
options(scipen = 999)

#' Extract tables from each type metaclusters
list_type_mk = unique( sce$type_mk )

#' Identify the number of state metaclusters used
n_state_mk = length( colnames( metadata(sce)$cluster_codes ) )
state_mk = paste0("meta", n_state_mk) # id used in CATALYST to identify which cluster used "metaXX"
list_sample_id = unique(sce$sample_id)

#' Create a loop to get one dataframe of abundance by type_mk

iteration = 1 # object to create a progress info
state_allmk = data.frame() # dataframe to save results in a unique dataframe

for(type_mk_i in list_type_mk) {

    #' message to follow the processus
    process = round( iteration/length(list_type_mk),2 ) * 100
    message("Extracting state marker abundances in ", type_mk_i, " (", process,"%)")
    
    #' create a sce object with only the type_mk
    sce_i = filterSCE( sce , type_mk == as.character(type_mk_i) )

    #' extract prop table of abundances
    tab_i = table( sce_i$sample_id,  cluster_ids(sce_i, state_mk) )

    #' compute relative abundance
    tab_prop_i = prop.table( tab_i, 1) * 100
    df_i = as.data.frame.matrix(tab_prop_i) 
    colnames(df_i) = paste0("state", colnames(df_i), "_", type_mk_i)

    #' seek absent sample_id ==> sample_id in which type_mk = 0
    list_sample_scei = unique(sce_i$sample_id)
    w = which( !(list_sample_id %in% list_sample_scei) )
    df_na = as.data.frame( matrix( nrow = length(w) , ncol = ncol(df_i) ) )
    df_na[is.na(df_na)] = 0 # fill NA with 0 since if cells  are absent : % of pop => 0
    row.names(df_na) = list_sample_id[w]
    colnames(df_na) = colnames(df_i)
    df_i = rbind( df_i, df_na )

    #' get row.names as a variable to allow tidy merge
    df_i$sample_id = row.names(df_i)
            
    #' save in a single data set : iteration = 1 create final dataset, iteration > 1 join datasets
    if( iteration == 1 ) { 
        state_allmk = df_i
    } else {
        state_allmk = state_allmk %>% full_join(df_i, )  }

    iteration = iteration + 1
    
}

#' save appended datasets
path_i = ("~/tmp/relab_fun_tcells.csv")
write.csv( state_allmk, row.names = FALSE, path_i )

message("Done\n")

rm(tab_i, sce_i, state_mk, n_state_mk, tab_prop_i, df_i, type_mk_i, list_type_mk, iteration, process, state_allmk, w, list_sample_scei, df_na, path_i)
