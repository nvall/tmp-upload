## Extract abundance data from SCE object
## Project AZIMUT
## Nicolas Vallet 

## The purpose of this script is to extract cluster abundance from a single cell experiment object

## require
library(CATALYST)
library(SingleCellExperiment)
library(tibble)

#' Input
## a SCE object with metaclusters and manually merged clusters
#' Output
## .csv file

#' Replace the path of the SCE object you want to extract
message("Reading SCE object")
sce = readRDS("~/R_output/sce_objects/sce_all_clustmergumap.RData")
message("Done\n")

#' remove scientific notation of decimals
options(scipen = 999)

#' extract events and relative abundance
t = table(sce$sample_id, cluster_ids(sce, "meta55") ) # create a table of events par patients ids
prop = prop.table(t, 1)*100

#' save .csv file
write.csv(prop, "~/tmp/relab_allcells.csv")

