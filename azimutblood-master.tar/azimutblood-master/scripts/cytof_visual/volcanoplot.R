## Script to draw volcanot plots
## Project AZIMUT
## Author: Nicolas Vallet

## Require
library(ggplot2)
library(RColorBrewer)
library(ggrepel)

## Inputs
### dataframe with results (median group1, median group2, p-val)
df = read.csv2("~/R_output/reports/mk_id_all_res_mww.csv")

### annotations
#annot = read_excel("~/metadata/mk_id55final.xlsx")

## indicate in which col, variable, median, pvalmay be found
col_var = 2
col_a   = 6
col_b   = 9
col_p   = 13

## create a new df with the data to plot
vp = df[ , c(col_var, col_a, col_b, col_p) ]
colnames(vp) = c("var", "a" , "b" , "pval")

## change var names if meta_all
vp$var = gsub(".{4}$"," ", vp$var)

## compute FC
vp$fc = vp[, 2]/vp[, 3]

## compute adjusted p.val
vp$fdrpval = p.adjust(vp[,  4]  , method="fdr")

## VP with raw pval

vp_raw = ggplot()+
    
    geom_point(data = vp, 
               aes(x = log(fc,2) , y = - log(pval,10)))+
    
    geom_point(data = vp[ vp[,4]<0.05 ,],
               aes(x = log(fc,2) , y = - log(pval,10) , color= " " , size = 2)) +
    
    geom_text_repel(data = vp[ vp[,4]<0.05 ,],
                    aes(x = log(fc,2) , y = - log(pval,10),  label = var ),
                    fontface = "bold",
                    size = 3,   
                    box.padding = unit(0.5, "lines"), # distance point
                    point.padding = unit(0.5, "lines") ) + # distance between start of line and point 

    geom_vline(xintercept = 0,linetype = "dashed", col = "grey22")+
    geom_hline(yintercept = -log(0.05,10) ,linetype = "dashed", col = "grey22")+

    
    
    xlab("log2(Fold Change)")+
    ylab("- log10(p-value)")+

    xlim(-2.5,2.5)+
    ylim(0,2.5) +

    annotation_logticks()+

    theme_classic()+
    theme(legend.position="none")+

    scale_color_brewer(palette="Dark2")



## VP with adjusted pval

sig = which ( vp[ , 6]<0.05 )

if ( length(sig) != 0 ) {

    vp_fdr = ggplot()+
        
        geom_point(data = vp, 
                   aes(x = log(fc,2) , y = - log(fdrpval,10)))+
        
        geom_point(data = vp[ vp[,6]<0.05 ,],
                   aes(x = log(fc,2) , y = - log(fdrpval,10) , color = " " )) +
        
        geom_text_repel(data = vp[ vp[, 6]<0.05 ,],
                        aes(x = log(fc,2) , y = - log(fdrpval,10),  label = var ),
                        size = 3,   
                        box.padding = unit(0.5, "lines"), # distance point
                        point.padding = unit(0.35, "lines") ) + # distance between start of line and point 

    geom_vline(xintercept = 0,linetype = "dashed", col = "grey22")+
    geom_hline(yintercept = -log(0.05,10) ,linetype = "dashed", col = "grey22")+

    xlab("log2(FC)")+
    ylab("-log10(FDR p-val)")+

    theme_classic()+
    theme(legend.position="none")+

    scale_color_brewer(palette="Dark2")

} else {
    
    vp_fdr = ggplot()+
        
        geom_point(data = vp, 
                   aes(x = log(fc,2) , y = - log(fdrpval,10)))+
        
        geom_vline(xintercept = 0,linetype = "dashed", col = "grey22")+
        geom_hline(yintercept = -log(0.05,10) ,linetype = "dashed", col = "grey22")+
        
        xlab("log2(FC)")+
        ylab("-log10(FDR p-val)")+

    theme_classic()+
    theme(legend.position="none")+

    scale_color_brewer(palette="Dark2")

}

## print result

pdf("~/R_output/figures/volcano.pdf")

print( vp_raw )
print( vp_fdr )

dev.off()

rm(vp, sig, col_var, col_a, col_b, col_p, df )
