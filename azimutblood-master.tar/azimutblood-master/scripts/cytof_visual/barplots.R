## Draw bar plots
## Project: AZIMUT
## Author: Nicolas Vallet

## Require
library(ggplot2)
library(readxl)
## input

### data to plot
df = read.csv("~/R_output/data/mk_id_all.csv")

### METADATA
meta = read_excel("~/metadata/metadata_sample.xlsx")

## merge dataframes
df_plot = merge (df, meta, by = 1)

## order groups
df_plot$group = factor(df_plot$group, c("HD", "PLA", "AZM") )

## get plot for 1 col


                                       
p = ggplot( df_plot , aes(x = group , y =  meta55_all , fill = group ) )+

    geom_boxplot( outlier.shape = NA ) +

    #geom_violin ( )+

    #geom_point(shape=21, fill = "white", color = "black") +

    theme_minimal() +

    labs( y = "meta55 / all cells" , x = "" ) +

    theme(axis.text.x = element_text(color = "black", face = "bold", size = 12),
          axis.title.y = element_text(color = "black", face = "bold", size = 12),
          axis.text.y = element_text(color = "black", face = "bold", size = 10),
          legend.position= "none" ) +

    #ylim( 0, 0 ) +

    scale_fill_brewer(palette = "Dark2")

