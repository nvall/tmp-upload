#' Create dotplot of %state_mk in type_mk from SCE object with state
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(CATALYST)
library(SingleCellExperiment)
library(ggplot2)
library(reshape)

#' Inputs
##' SCE object
sce = readRDS("~/R_output/sce_objects/sce_tcells_func_clust.RData")

##' Filter SCE object according to group
sce_hd  = filterSCE(sce, condition == "HD")
sce_pts = filterSCE(sce, condition != "HD")
sce_azm = filterSCE(sce, condition == "AZM")
sce_pla = filterSCE(sce, condition == "PLA")

##' Get dotplots
list_sce = c("sce_hd","sce_pts","sce_azm","sce_pla")

##' Create a list of plots
list_plot = list()
j = 1 # iteration to save plots

###' Get type metaclusters annotations
annotations = read_excel("~/Git/azimutblood/metadata/mk_id55final.xlsx")
annotations$mk_id = paste0("typemk",annotations$mk_id) # use the same nomenclature

###' Start loop
for (mk in list_sce) {

    sce_i = get( mk )
    
    #' Get a dataframe with n events of functional metaclusters
    df = table(sce_i$type_55mk,
               cluster_ids(sce_i, "meta25") )
    df_nevent = as.data.frame.matrix( df ) # transform in a dataframe

    #' compute % of functional metaclusters in each type metaclusters
    df_pour =  as.data.frame.matrix( prop.table(df , 1) * 100 )

    #' Draw dotplots from df_pour
    ## format the dataframe to be able to plot the results
    df_pour$typemk = row.names( df_pour )
    df_melt = melt(df_pour, id.vars = "typemk" )
    df_melt$variable = paste0( "state", df_melt$variable )
    df_melt$typemk_annot = NA

    ## loop to rename type metaclusters with annotation
    for(i in 1:nrow(df_melt) ) {
        type = df_melt[ i , ]$typemk
        line_i = which( annotations$mk_id == type )   
        df_melt[ i , ]$typemk_annot = paste0(type, "_", annotations[ line_i , "merge3"] )
    }

    #' Get the dot plot with % state markers by type markers
    dotplot = ggplot(df_melt, aes(x = variable , y = typemk_annot, size = value, color = value ) ) +
        geom_point() +
        theme_minimal()+
        guides(color = guide_legend(order=1),
               size = guide_legend(order=2)   ) +
        ggtitle( mk )+
        theme(legend.title = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y = element_blank(),
              axis.text.x = element_text( color="black", 
                                         size=10, angle=45),
              axis.text.y = element_text(  color="black", 
                                         size=10, angle=0) )+
        scale_x_discrete(position = "top") +
        scale_colour_gradient2(low = "#ffeda0", mid = "#feb24c", high = "#f03b20")

    list_plot[[ j ]] = dotplot

    j = j+1

}

#' Print result
pdf("~/R_output/figures/dotplots_gp.pdf", width=11.7, height=8.3 )
for(i in 1:length(list_plot) ) {
    print( list_plot[[i]] )
}
dev.off()
