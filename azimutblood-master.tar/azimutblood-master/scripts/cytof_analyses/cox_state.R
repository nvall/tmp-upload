#' Survival competive risk analysis
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(survival)
library(riskRegression)
library(prodlim)
library(cmprsk)

#' remove scientific notation of decimals
options(scipen = 999)

#' metadata - get from script to prepare clinical data format and compute time differences
source("~/Git/azimutblood/scripts/datamanagement/clinical.R") # the output is a dataframe named "md"

#' setwd
setwd("~/Git/azimutblood/data/cytof/state_mk")

#' get the files to test 
list_file = list.files()

#' start loop ------------------------------------------------------------------------------------
iteration_file = 1

for(tested_file in list_file) {

    #' message to follow the process
    process_file = round(iteration_file/length(list_file),2)*100
    message("Now calculating HR for ", tested_file," (", process_file, "%)")

    #' read dataframe from 1 file 
    df_file = read.csv2(tested_file, row.names = 1) *100 # *100 => to get %

    #' merge md and df_file
    dfall = merge(df_file, md, by = 0)
    dfall = subset(dfall, group != "HD" )

    #' split df in AZM and PLA groups
    dfazm = subset(dfall , group == "AZM")
    dfpla = subset(dfall , group == "PLA")
    
    #' get the names of dataframes to use for the cpmrsk event loop
    list_df = c("dfall", "dfazm", "dfpla")

    
    #' get 95%CI for all mk_id/allcells UNIVARIATE  ---------------------------------------------

    #'' create a dataframe to store the results
    mk = grep( "state", colnames( dfall ), fixed = TRUE ) # get the colums number with of variable to test
    res_cmprsk_cohort = data.frame( matrix ( nrow = length(mk) , ncol = 5 ) )
    colnames(res_cmprsk_cohort) = c("var", "hr", "l95ci", "h95ci", "pval")

    #'' start the loop ( for each DF, get each col in the cmprsk model )
    for(dataframe in list_df) {
        
        #' get the the dataframe to use in df_i
        df_i = get( dataframe )

        #' create a link to save the .csv ouput
        path_to_save_res = paste0( "~/tmp/res_cox_univ_", dataframe,"_", tested_file ) 

        #' create an object to increment the results in the .csv ouput
        row_i = 1
        
        #' start the loop to compute all univariate analyses
        for (i in 1:length( mk ) ) {

            #' get columns with explicative variable
            col_i = mk[i] 
            #' get the name of the variable 
            name_i = colnames( df_i[col_i] ) ########

            #' create a formula that will be used in the model
            form_i = as.formula ( paste0( "Surv(del_relapse, relapse == 'Relapse') ~ ", name_i  ) )

            #' compute the model 
            mod_i = coxph(  form_i  , data = df_i )

            #' save summary
            sum_i = summary(mod_i)

            #' store results in the dataframe
            res_cmprsk_cohort[row_i, 1] = name_i ## var name
            
            res_cmprsk_cohort[row_i, 2] = sum_i$coefficients[2]     ## HR
            res_cmprsk_cohort[row_i, 3] = sum_i$conf.int[3] ## low 95%CI
            res_cmprsk_cohort[row_i, 4] = sum_i$conf.int[4] ## high 95%CI

            res_cmprsk_cohort[row_i, 5] = sum_i$coefficients[5]     ## p val

            #' increment row_i
            row_i = row_i + 1

        }
        
        #' compute adjusted pvals
        res_cmprsk_cohort$pval_fdr = p.adjust(res_cmprsk_cohort$pval, method = "fdr")
            
        #' save the table .csv file
        write.csv2( res_cmprsk_cohort, path_to_save_res, row.names = FALSE)
        
    }
    
    iteration_file = iteration_file + 1 

}


#' END OF THE SCRIPT : clear objects and message ---------------------------------------
rm(list_file, iteration_file, df_file, dfall, dfazm, dfpla)
rm(  col_i,name_i, form_i, mod_i, sum_i, res_cmprsk_cohort, row_i, df, dfazm, dfpla  )
message("\nDone")
