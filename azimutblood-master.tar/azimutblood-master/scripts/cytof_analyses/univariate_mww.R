#' Univariate comparison between groups of 55 metaclusters
#' Project AZIMUT
#' Author: Nicolas Vallet

#' Require
library(ggplot2)
library(RColorBrewer)
library(readxl)
library(reshape2)

#' remove scientific notation of decimals
options(scipen = 999)

#' Inputs
source("~/Git/azimutblood/scripts/datamanagement/pca_prepare_df.R")

input = subset( mergabun, rel12 == "CR12") 

### create a result table REL12 v CR12
res = NULL # reset res_i
res = as.data.frame(matrix (nrow = 55 , ncol = 9 ) ) # minus 1 because first col = sample_id
colnames(res) = c("var",  "REL_med", "REL_iqr1", "REL_iqr3", "CR_med", "CR_iqr1", "CR_iqr3", "p-val-mww", "p-val-t")

## get the stats REL12 v CR12
row_res = 1
for(i in 2:56) { # cols in which stats will be performed
    
    ## get the name of the tested variable
    var = names( input [ i ] )

    ## get the of each col in each groups
    REL_col  = input[ input$rel12 == "REL12",  i ]
    CR_col = input[ input$rel12 == "CR12", i ]
 
    ## summary of res
    sREL  = summary(REL_col)
    sCR = summary(CR_col)

    ## perform the stats
    test = wilcox.test( REL_col, CR_col, paired = FALSE, correct = FALSE )
    test_t = t.test( REL_col, CR_col )

    ## save stats
    res[row_res, 1] = var

    res[row_res, 2] = sREL [3]
    res[row_res, 3] = sREL [2]
    res[row_res, 4] = sREL [4]

    res[row_res, 5] = sCR [3]
    res[row_res, 6] = sCR [2]
    res[row_res, 7] = sCR [4]

    res[row_res, 8] = test [3]
    res[row_res, 9] = test_t [3]

    row_res = row_res + 1

}


### create a result table
res = NULL # reset res_i
res = as.data.frame(matrix (nrow = 55 , ncol = 12 ) ) # minus 1 because first col = sample_id
colnames(res) = c("var", "HD_med", "HD_iqr1", "HD_iqr3", "AZM_med", "AZM_iqr1", "AZM_iqr3", "PLA_med", "PLA_iqr1", "PLA_iqr3", "p-val-mww", "p-val-t")



## get the stats AZM v PLA
row_res = 1
for(i in 2:56) { # cols in which stats will be performed
    
    ## get the name of the tested variable
    var = names( input [ i ] )

    ## get the of each col in each groups
    HD_col  = input[ input$group == "HD",  i ]
    AZM_col = input[ input$group == "AZM", i ]
    PLA_col = input[ input$group == "PLA", i ]

    ## summary of res
    sHD  = summary(HD_col)
    sAZM = summary(AZM_col)
    sPLA = summary(PLA_col)

    ## perform the stats
    test = wilcox.test( PLA_col, AZM_col, paired = FALSE, correct = FALSE )
    test_t = t.test( PLA_col, AZM_col ) 

    ## save stats
    res[row_res, 1] = var

    res[row_res, 2] = sHD [3]
    res[row_res, 3] = sHD [2]
    res[row_res, 4] = sHD [4]

    res[row_res, 5] = sAZM [3]
    res[row_res, 6] = sAZM [2]
    res[row_res, 7] = sAZM [4]

    res[row_res, 8] = sPLA [3]
    res[row_res, 9] = sPLA [2]
    res[row_res, 10] = sPLA [4]
    res[row_res, 11] = test [3]
    res[row_res, 12] = test_t [3]

    row_res = row_res + 1

}


## print stats in .csv file
path_res_save = paste0("~/R_output/reports/azmpla_univ_",name_i,"_res",".csv" )
write.csv2(res_i, path_res_save)





