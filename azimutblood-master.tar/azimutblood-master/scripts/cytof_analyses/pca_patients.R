#' PCA analysis for patients without HD
#' Project AZIMUT
#' Author: Nicolas Vallet

#' Take a dataframe prepared by PCA management of dataframe script
#' Print PCA axis and contribution for df with all pts and only AZM or PLA patients
#' Make sure to enter your input

#' Require
library(FactoMineR)
library(factoextra)
library(RColorBrewer)
library(cowplot)
library(readxl)
library(reshape)

#' inputs ------------------------------------------------------------
source("~/Git/azimutblood/scripts/datamanagement/pca_prepare_df.R")

input = mergabun


#' Set conditions -----------

df_all = subset(input, group != "HD"  )
df_azm = subset(input, group == "AZM" )
df_pla = subset(input, group == "PLA" )

df_all$group = factor( df_all$group )
df_azm$group = factor( df_azm$group )
df_pla$group = factor( df_pla$group )

df_rel = subset( input, rel12 == "REL12")
df_cr  = subset( input, rel12 == "CR12" )

#' list of all df to use 
list_df = c("df_all", "df_azm", "df_pla", "df_rel", "df_cr")

#' loop to create plots

for( i in 1:length(list_df) ) {
    
    #' get the DF from list_df
    df_i = get( list_df[i] )

    #' create PCA result => 2:56 because with datamanagement 2 first row and 56 last row of metaclusters for mergmean or mergmed last col is 44
    res_i = PCA(df_i[ , c(2:56) ], graph = F)

    #' print scree plots and contributions
    scree_i = fviz_screeplot(res_i, addlabels = TRUE)

    cont1 = fviz_contrib(res_i, choice = "var", axes = 1, top = 30) 
    cont2 = fviz_contrib(res_i, choice = "var", axes = 2, top = 30)
    cont3 = fviz_contrib(res_i, choice = "var", axes = 3, top = 30)
    cont4 = fviz_contrib(res_i, choice = "var", axes = 4, top = 30)
    cont5 = fviz_contrib(res_i, choice = "var", axes = 5, top = 30)

    plot = plot_grid(scree_i, cont1, cont2, cont3, cont4, cont5, ncol = 1)
    
    print_scree_i = paste0("~/tmp/pca_contrib_",list_df[[i]],".pdf")
    
    pdf(print_scree_i, width = 10 , height = 25)
    print(plot)
    dev.off()

    #' get col number with supplementary cat variables (if in subgroup do not plot AZM or PLA plots)
    if( list_df[i] == "df_all" ) {
        col_sup_var = which( colnames(df_i) %in% c( "group", "agvhd", "relapse", "rel12" ) )
    }

    if( list_df[i] == "df_azm" | list_df[i] == "df_pla" ) {
        col_sup_var = which( colnames(df_i) %in% c(  "agvhd", "relapse", "rel12" ) )
    }

    if( list_df[i] == "df_rel" ) {
        col_sup_var = which( colnames(df_i) %in% c(  "group", "agvhd" ) )
    } 


    #' number of plot to append in list
    n_plot = 1

    #' set a new list of plots
    list_of_plots = list( NULL )
    
    #' loop to search j in col_sup_var and perfom axis plot for each group discrimination
    for( j in col_sup_var ) {

         
        p12 = fviz_pca_ind(res_i,
                           axes = c(1,2),
                           col.ind=df_i[, j],
                           label = "none",
                           title = "",
                           legend= "",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p13 = fviz_pca_ind(res_i,
                           axes = c(1,3),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")

        p14 = fviz_pca_ind(res_i,
                           axes = c(1,4),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p15 = fviz_pca_ind(res_i,
                           axes = c(1,5),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p23 = fviz_pca_ind(res_i,
                           axes = c(2,3),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p24 = fviz_pca_ind(res_i,
                           axes = c(2,4),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p25 = fviz_pca_ind(res_i,
                           axes = c(2,5),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p34 = fviz_pca_ind(res_i,
                           axes = c(3,4),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p35 = fviz_pca_ind(res_i,
                           axes = c(3,5),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")


        p45 = fviz_pca_ind(res_i,
                           axes = c(4,5),
                           col.ind=df_i[, j],
                           title = "",
                           legend= "",
                           label = "none",
                           pointsize = 0.5,
                           ggtheme=theme_bw(),
                           addEllipses = T,
                           ellipse.type = "confidence",
                           ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")

        #' get legend
        plot_legend = fviz_pca_ind(res_i,
                                   col.ind=df_i[, j],
                                   title = "",
                                   ggtheme=theme_bw(),
                                   addEllipses = T,
                                   ellipse.type = "confidence",
                                   ellipse.level = 0.95)+
            scale_color_brewer(palette = "Dark2")

        legend = get_legend(plot_legend)
        
        final_plot = plot_grid (ncol = 5, nrow = 4,
                                legend, p12, p13, p14, p15,
                                NULL, NULL, p23, p24, p25,
                                NULL, NULL, NULL, p34, p35,
                                NULL, NULL, NULL, NULL, p45)

        list_of_plots[[n_plot]] = final_plot
        n_plot = n_plot + 1
        
    } 
    
    #' loop to print results
    print_axis_k = paste0("~/tmp/pca_axis_",list_df[[i]],".pdf")
    pdf(print_axis_k, width = 12 , height = 10)
    for(k in 1:length( list_of_plots ) ) {
        
        print( list_of_plots[[k]] )
    }
        
    dev.off()

}

rm(list=ls())
