#' Survival competive risk analysis
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(survival)
library(riskRegression)
library(prodlim)
library(cmprsk)

#' remove scientific notation of decimals
options(scipen = 999)


#'' Inputs -----------------------------------------------------------------------
message("Reading inputs dataframes\n")

#' mk_id data
mk_id = read.csv("~/Git/azimutblood/data/cytof/mk_id_all.csv",
                 row.names = 1)
mk_id = mk_id*100 # multiply by 100 to get data in %

#' metadata - get from script to prepare clinical data format and compute time differences
source("~/Git/azimutblood/scripts/datamanagement/clinical.R") # the output is a dataframe named "md"

#' merge
df = merge(mk_id, md, by = 0)
rm(mk_id) # remove unused df

#' split df in AZM and PLA groups
dfazm = subset(df , group == "AZM")
dfpla = subset(df , group == "PLA")

#' get the names of dataframes to use for the cpmrsk event loop
list_df = c("df", "dfazm", "dfpla")

#' get 95%CI for all mk_id/allcells UNIVARIATE  ---------------------------------------------
message("Starting univariate analysis\n")

#' create a dataframe to store the results
mk = grep("meta", colnames(df), fixed = TRUE) # get the colums number with of variable to test
res_cmprsk_cohort = data.frame( matrix ( nrow = length(mk) , ncol = 5 ) )
colnames(res_cmprsk_cohort) = c("var", "hr", "l95ci", "h95ci", "pval")

#' start the loop ( for each DF, get each col in the cmprsk model )
for(dataframe in list_df) {
    
    #' get the the dataframe to use in df_i
    df_i = get(dataframe)

    #' create a link to save the .csv ouput
    path_to_save_res = paste0("~/tmp/res_cmprsk_univ_",dataframe,".csv") 

    #' create an object to increment the results in the .csv ouput
    row_i = 1
    
    #' start the loop to compute all univariate analyses
    for (i in 1:length( mk ) ) {

        #' get columns with explicative variable
        col_i = mk[i] 
        #' get the name of the variable 
        name_i = colnames( df[col_i] )

        #' create a formula that will be used in the model
        form_i = as.formula ( paste0("Hist (del_relapse, relapse, cens.code = 'Censored') ~ ", name_i ) )

        #' compute the model 
        mod_i = FGR(  form_i  , data = df_i , cause = "Relapse" )

        #' save summary
        sum_i = summary(mod_i)

        #' store results in 
        res_cmprsk_cohort[row_i, 1] = name_i ## var name
        
        res_cmprsk_cohort[row_i, 2] = sum_i$coef[2]     ## HR
        res_cmprsk_cohort[row_i, 3] = sum_i$conf.int[3] ## low 95%CI
        res_cmprsk_cohort[row_i, 4] = sum_i$conf.int[4] ## high 95%CI

        res_cmprsk_cohort[row_i, 5] = sum_i$coef[5]     ## p val

        #' increment row_i
        row_i = row_i + 1

        }

    #' compute adjusted pvals
    res_cmprsk_cohort$pval_fdr = p.adjust(res_cmprsk_cohort$pval, method = "fdr")
        
    #' save the table in a list
    message("Saved results of ", dataframe, " to ", path_to_save_res)
    write.csv2( res_cmprsk_cohort, path_to_save_res, row.names = FALSE)
    
}

#' END OF THE SCRIPT : clear objects and message ---------------------------------------
rm(  col_i,name_i, form_i, mod_i, sum_i, res_cmprsk_cohort, row_i, df, dfazm, dfpla  )
message("\nDone")
