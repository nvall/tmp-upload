## Univariate comparison between AZM and PLA groups and display HD data
## Project AZIMUT
## Author: Nicolas Vallet

## Require
library(ggplot2)
library(RColorBrewer)
library(readxl)
library(reshape2)

## remove scientific notation of decimals
options(scipen = 999)

## Inputs

### path to data to test
path = "~/R_output/data/"

### DATAFRAME TO TEST : put all datasets to test in the same folder
#### get datasets names to test from the folder
df_files = list.files(path)
#### remove extension from file name
df_names = sub(".csv","", df_files, fixed = TRUE)

### METADATA
meta = read_excel("~/metadata/metadata_sample.xlsx")
meta = as.data.frame(meta)

## loop to get results

for (i in 1:length( df_names ) ) {
    
    ## get the name and df to test
    file_i = df_files [ i ]
    name_i = df_names [ i ]
    
    ## read df
    path_i = paste0( path, file_i )
    df_i = read.csv( path_i, na.strings = "NA", check.names = FALSE)

    ## check for NA : these NA correspond to relative abundances that were not computed because 0 value in denominator. Thus, these relative abundances correspond to 0. Here we append 0 value to NAs
    df_i[ is.na(df_i) ] = 0

    ## merge with metadata group
    merge_i = merge(df_i, meta, by= 1 )

    ## setup output objects
    ### create a result table
    res_i = NULL # reset res_i
    res_i = as.data.frame(matrix (nrow = ( ncol(df_i) - 1 ) , ncol = 12 ) ) # minus 1 because first col = sample_id
    colnames(res_i) = c("var", "HD_med", "HD_iqr1", "HD_iqr3", "AZM_med", "AZM_iqr1", "AZM_iqr3", "PLA_med", "PLA_iqr1", "PLA_iqr3", "p-val-mww", "p-val-t")

    ### setup a list of plots
    plot_list = list()

    ## get the stats
    for (col in 2 : ncol(df_i) ) {
   
        ## get the name of the tested variable
        var = names( df_i [ col ] )

        ## get col in merge_i
        var_col = which ( colnames( merge_i ) == var )

        ## saving row
        row_res = col-1

        ## get the of each col in each groups
        HD_col  = merge_i[ merge_i$group == "HD",  var_col ]
        AZM_col = merge_i[ merge_i$group == "AZM", var_col ]
        PLA_col = merge_i[ merge_i$group == "PLA", var_col ]
        
        ## summary of res
        sHD  = summary(HD_col)
        sAZM = summary(AZM_col)
        sPLA = summary(PLA_col)

        ## perform the stats
        test = wilcox.test( PLA_col, AZM_col, paired = FALSE, correct = FALSE )
        test_t = t.test( PLA_col, AZM_col ) 
        
        ## save stats
        res_i[row_res, 1] = var
        
        res_i[row_res, 2] = sHD [3]
        res_i[row_res, 3] = sHD [2]
        res_i[row_res, 4] = sHD [4]

        res_i[row_res, 5] = sAZM [3]
        res_i[row_res, 6] = sAZM [2]
        res_i[row_res, 7] = sAZM [4]

        res_i[row_res, 8] = sPLA [3]
        res_i[row_res, 9] = sPLA [2]
        res_i[row_res, 10] = sPLA [4]
        res_i[row_res, 11] = test [3]
        res_i[row_res, 12] = test_t [3]

    }    

    ## get the ggplots 

    for (col in 2 : ncol( df_i ) ) {

        ## get the name of the var
        var = names( df_i [ col ] )

        ## get the df with values from var
        df_plot = melt(merge_i, measure.vars = as.character( var ) )

        ## get the Y title
        title = sub ("_" , " / ", var)
        title = paste0("%", title)

        ## order groups
        df_plot$group = factor(merge_i$group, c("HD", "PLA", "AZM") )
        
        ## get plot for 1 col
        plot_col = ggplot( df_plot , aes(x = group , y =  value , fill = group ) )+
            geom_boxplot( outlier.shape = NA ) +
            geom_point(shape=21, fill = "white", color = "black", position = "jitter") +
            theme_minimal() +
            labs( y = title , x = "" ) +
            theme(axis.text.x = element_text(color = "black", face = "bold", size = 12),
                  axis.title.y = element_text(color = "black", face = "bold", size = 12),
                  axis.text.y = element_text(color = "black", face = "bold", size = 10),
                  legend.position= "none" ) +
            ylim( 0, 1 ) +
            scale_fill_brewer(palette = "Dark2")

        ## save plot in a intermediate object
        plot_list[[ var ]] = plot_col
        
    }
        
    ## print stats in .csv file
    path_res_save = paste0("~/R_output/reports/azmpla_univ_",name_i,"_res",".csv" )
    write.csv2(res_i, path_res_save)

    ## print plots
    path_pdf_save = paste0("~/R_output/reports/",name_i,"_plots",".pdf" )
    pdf( path_pdf_save, width = 3.5, height = 7 )

    for (k in 1 : length( plot_list ) ) {

        print( plot_list[[ k ]] )

       }

    dev.off()
    
}

        


