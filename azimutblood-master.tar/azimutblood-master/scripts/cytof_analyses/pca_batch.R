## Evaluate batch effect with PCA
## Project: AZIMUT
## Author: Nicolas Vallet


## Require
library(FactoMineR)
library(factoextra)
library(RColorBrewer)
library(cowplot)
library(readxl)
library(reshape)

## inputs
source("~/Git/azimutblood/scripts/datamanagement/pca_prepare_df.R")

## choose a df for the PCA


#### PCA  --------------------------------

df_acp = mergabun

res.pca <- PCA(df_acp[, c(2:56)], graph=F )

#'' plot scree and contributions
scree = fviz_screeplot(res.pca, addlabels = TRUE) # scree plot

cont1 = fviz_contrib(res.pca, choice = "var", axes = 1, top = 50) 
cont2 = fviz_contrib(res.pca, choice = "var", axes = 2, top = 50)

plot = plot_grid(scree, cont1, cont2, nrow=3)

pdf("~/tmp/pca_contrib.pdf", width = 10 , height = 15)
print(plot)
dev.off()

#'' plot dim 1 and 2 
ind = fviz_pca_ind(res.pca,
                   axes = c(1,2),
                   #col.ind= "cos2",
                   #label = "none",
                   ggtheme=theme_bw(),
                   repel = TRUE
                   #gradient.cols = c( brewer.pal(6, "YlGnBu") )
                   )


group = fviz_pca_ind(res.pca,
                     axes = c(1,2),
                     col.ind=df_acp$group,
                     label = "none",
                     ggtheme=theme_bw(),
                     addEllipses = T,
                     ellipse.type = "confidence",
                     ellipse.level = 0.95)+
    scale_color_brewer(palette = "Dark2")


batch = fviz_pca_ind(res.pca,
                     col.ind=df_acp$batch,
                     label="quali",
                     ggtheme=theme_bw(),
                     addEllipses = T,
                     ellipse.type = "confidence",
                     ellipse.level = 0.95)

contrib = fviz_pca_var(res.pca,
                       col.var = "cos2",
                       gradient.cols = c( brewer.pal(6, "YlGnBu") ),
                       repel = TRUE # Évite le chevauchement de texte
                       ) 

plot = plot_grid(ind, group, batch, contrib)

pdf("~/tmp/pca_axes.pdf", width = 11.7 , height = 8.3)
print(plot)
print(ind)
print(group)
print(batch)
print(contrib)
dev.off()


## plot markers according to date

#' insert dataframe to plot
dfvioplot = mergmean

#' get number of colums
n_col_dfvioplot = ncol(dfvioplot) - 11

#' transform the datasets
dfmelt = melt(dfvioplot,  id.vars = c("batch", "Row.names","sample_id","allozithro_id","group","Row.names.y") )

#' create a new objet to store plts
all_plots = list()

#' iteration to store plots
j=1

#' loop to create all plot
for( i in 2:n_col_dfvioplot ) {

    # get var name
    var = colnames(dfvioplot)[i]

    # compute mean and IQR
    mean_i = mean(dfmelt[ dfmelt$variable == var, "value" ] )
    iqr1_i = summary( dfmelt[ dfmelt$variable == var, "value" ] )[[2]]
    iqr3_i = summary( dfmelt[ dfmelt$variable == var, "value" ] )[[5]]

    # start plot
    plot_i = ggplot(dfmelt[ dfmelt$variable == var , ] , aes(x=batch, y = value) ) +
    
    
    geom_hline(yintercept= mean_i , linetype= "solid", color = "black")  +
    geom_hline(yintercept= iqr1_i , linetype= "dashed", color = "black") +
    geom_hline(yintercept= iqr3_i , linetype= "dashed", color = "black") +

    geom_violin( fill = "lightgrey") +
    geom_point( aes( fill = group ), shape = 21,  size = 1.5)+
    
    theme_minimal() +
    ylab("Arcsin transformed")+
    xlab("")+
    ggtitle(var) +
    
    theme(axis.text.x = element_text(face="bold", color= "black", 
                                     size=10, angle=90),
          axis.text.y = element_text(face="bold", color="black", 
                                     size=10) ) +

    scale_color_brewer( palette= "Dark2") 

 
    # store the plot
    all_plots[[j]] = plot_i

    # append j
    j = j+1

}

#' print the plots in pdf
pdf("~/tmp/plots_batch.pdf", width = 11.7 , height = 8.3 )

for(i in 1:length(all_plots) ) {
    print( all_plots[[i]] )
}
dev.off()
