# CyTOF Merging metaclusters from FlowSOM
# Project AZIMUT
# Author: Nicolas Vallet

# This script aims at merging and annotating clusters in a SCE object
# input :
#* SCE object with FlowSOM object
#* A table with corresponding annotations

# REF : https://www.bioconductor.org/packages/release/workflows/vignettes/cytofWorkflow/inst/doc/cytofWorkflow.html

# require
library(CATALYST)
library(readxl)
library(flowCore)
library(cowplot)
library(RColorBrewer)

# warning message (for metaclusters n=55)
print("!! this script must be used for n=55 metaclusters !!")

# Load SCE object

message("Reading sce")
    
sce = readRDS(file="~/R_output/sce_objects/sce_all_clust.RData")

# Load metadata table with all merging columns
#* prepare merging tables
#* mergeClusters function from CATALYST uses tables with 2 columns the first is the original cluster names mais the second is the new names: subtable will be created according to the number of merging needed

mergetable = read_excel("~/metadata/mk_id55final.xlsx")
    
print(
head(mergetable)
)

#* loop to create all tables requiered for merging and creates a list of merging table to run merging
i = numeric() # loop iteration
name_i = character() # name of merging table
mergelist = list() # list of table to create

for (i in 2:ncol(mergetable) ) {
    
    name_i = colnames(mergetable[i])
    
    mergelist[[name_i]] = mergetable[ , c(1,i) ]
    
}

rm(i, name_i)

message("merging tables ready")

# Merging

message("performing merging")

#* loop to perform all merging
i = numeric() #loop iterations
merge_i = character() # name the future merging
merging_table = NULL # will be appended with the merge list
meta_n = paste0("meta",55) # change number of metaclusters here, if needed


for (i in 1:length(mergelist) ) {
    
    message("merging: ",i,"/",length(mergelist) )
    
    merge_i = names( mergelist[i] )
    
    merging_table = mergelist[i]
    
    sce <- mergeClusters(sce, k = meta_n, table = merging_table, id = merge_i )
    
}

rm(i, merging_table, meta_n)
    
message("Done")

# Check merging by printing heatmaps

message("plotting heatmaps")

plot_list = list() # plotlist
plot = NULL # plot saved in loop

for (i in 1:length(mergelist) ) {
    
    merge_i = names(mergelist[i])
    
    plot = plotExprHeatmap(sce,
        features = "type",
        scale = "last",
        by = "cluster_id",
        k = merge_i,
        row_anno = FALSE,
        hm_pal = brewer.pal(n=9,name="YlGnBu"),
        bars = TRUE,
        perc = TRUE
        )
        
    plot_list[[i]] = plot

}

rm(i, plot)

pdf("~/R_output/figures/flowsom_merged.pdf", width=11.7, height=8.3)

for (i in 1:length(plot_list) ) {
    print(plot_list[[i]])
}

dev.off()

message("Done")

rm(i, plot_list)

# Saving SCE object

message("Saving SCE object")

saveRDS(sce, file="~/R_output/sce_objects/sce_all_clustmerg.RData")

message("Done")
