# CyTOF CLUSTER CELLS METACLUSTERS SCREENING
# Project AZIMUT
# Nicolas Vallet

# This script aims at screening different number of metaclusters to determine the optimal number of metaclusters for clustering single cells from a SCE objects with FlowSOM
# A heatmap of the resulting clusters is then printed in pdf

# REF : https://www.bioconductor.org/packages/release/workflows/vignettes/cytofWorkflow/inst/doc/cytofWorkflow.html

# require
library(CATALYST)
library(readxl)
library(flowCore)
library(cowplot)
library(RColorBrewer)

print("starting FlowSOM tests from 30 to 70, by 5")

metaK = seq(from=30, to=70, by=5)

meta = "meta"

for (i in 1:length(metaK) ) {
    
    metai = as.numeric(metaK[i]) # n metaK to test
    
    metaKi = paste(meta,metai,sep="") # name metaK
    
    metaKi = as.character(metaKi)
    
    linki = paste("~/R_output/figures/",metaKi,".pdf",sep="") # link to save
    
    message("starting FlowSOM with n=", metai, " metaclusters ", "(",i,"/",length(metaK)," to test)" )
    
    # Load the SCE file
    
    message("reading sce")
    
    sce = readRDS(file="~/R_output/sce_objects/sce_allcells.RData")
    
    # FLOWSOM clustering ----
    
    message("starting clustering")
    
    set.seed(42)
    sce <- cluster(sce, features = "type",
    xdim = 17, ydim = 17, maxK = metai, seed = 42,
    verbose = TRUE )
    
    
    # print FLOWSOM ----
    
    message("print pdf result")
    
    pdf(linki, width=11.7, height=8.3)
    
    print(
    
        plotExprHeatmap(sce,
        features = "type",
        scale = "last",
        by = "cluster_id",
        k = metaKi,
        row_anno = TRUE,
        hm_pal = brewer.pal(n=9,name="YlGnBu"),
        bars = TRUE,
        perc = TRUE )
    
    )
    
    dev.off()
    
    print("done")
    
    rm(metai, metaKi, linki, sce)
}

rm(meta,metaK)

a = sessionInfo()
writeLines(capture.output(sessionInfo()), "~/R_output/figures/metaKscreen_info.txt")
rm(a)
