# CyTOF CLUSTERING FLOWSOM WITH OPTIMAL NUMBER OF METAK
# Project AZIMUT
# Author: Nicolas Vallet

# This script aims at clustering events with optimal metacluster number (defined after screening)
# A heatmap of the resulting clusters is then printed in .pdf.

# REF : https://www.bioconductor.org/packages/release/workflows/vignettes/cytofWorkflow/inst/doc/cytofWorkflow.html

# require
library(CATALYST)
library(readxl)
library(flowCore)
library(cowplot)
library(RColorBrewer)

# The user enters the number of metacluster to create

meta = as.numeric(readline(prompt="Enter the number of metaclusters ") ) 

message("FlowSOM will be run with n=",meta," metaclusters.")

# Load SCE object

message("Reading sce")
    
sce = readRDS(file="~/R_output/sce_objects/sce_allcells.RData")

# Run flowsom clustering

metai = as.character( paste("meta",meta,sep="") ) # create the object that will be used in plots formulas

message("Clustering with n=", meta, " metaclusters")
    
set.seed(42)
sce = cluster(sce, 
		features = "type",
		xdim = 17, ydim = 17, maxK = meta, seed = 42,
		verbose = TRUE )
    
message("Done")

# Print flowsom result

message("Printing flowsom pdf result")
    
pdf("~/R_output/figures/flowsom_final.pdf", width=11.7, height=8.3)
    
print(
    
        plotExprHeatmap(sce,
        features = "type",
        scale = "last",
        by = "cluster_id",
        k = metai,
        row_anno = FALSE,
        hm_pal = brewer.pal(n=9,name="YlGnBu"),
        bars = TRUE,
        perc = TRUE
        )
    
	)
    
dev.off()
    
message("Done")


# Saving SCE object

message("Saving SCE object")

saveRDS(sce, file="~/R_output/sce_objects/sce_all_clust.RData")

message("Done")

# print session info

writeLines(capture.output(sessionInfo()), "~/R_output/figures/flowsom_rundr_info.txt")

message("End of the script")
