## Draw scatterplots to check FlowSOM metaclusters annotations on functionnal markers
## Project AZIMUT
## Nicolas Vallet

## require
library(CATALYST)
library(scater)
library(cowplot)
library(readxl)
library(ggplot2)
library(RColorBrewer)
library(reshape)

#' Script performs a FlowSOM clustering with choosen number of metaclusters
#' Draw heatmap of functionnal clusters and antigen expression within
#' Draw dotplot of state abundance within type metaclusters
#' Then draw scatter plots to visually inspect the events in each metaclusters
#' Run diffusion map dimension reduction
#' save the SCE object as a Robject

#' Define the number of metaclusters to check
meta = 25 # as.numeric(readline(prompt="Enter the number of state metaclusters ") ) 
message("FlowSOM will be run with n=",meta," metaclusters.")

k = paste0("meta", meta) # transform the promptline in interpretable vector in CATALYST

#' define dotplots
ch_all = list(c( "CD3" , "CD45" ),
              c( "CD8" , "CD4" ) ,
              c( "CD45" , "CD27" ),
              c( "CD25" , "CD127" ),
              c( "GranzymeB" , "CD45" ),
              c( "Eomes",  "CD45" ),
              c( "Tbet" ,  "CD45" ),
              c( "ICOS" ,  "CD45" ),
              c( "CTLA-4",  "CD45"),
              c( "OX40" ,  "CD45" ),
              c( "PD-1" ,  "CD45" ),
              c( "Tox" ,   "CD45" ),
              c( "LAG-3" , "CD45" ),
              c( "TIM-3" , "CD45" ),
              c( "4-1BB" , "CD45" ),
              c( "TIGIT" , "CD45" ),
              c( "KLRG1" , "CD45" ),
              c( "2B4" ,   "CD45" )
              )
              
message("Done \n")

#' Get the SCE object with T cells only and reallocated state markers that were also used for type identification (eg. PD1, Tbet)
source("~/Git/azimutblood/scripts/cytof_tcellfunct/cytof_func_prep_sce_tcells.R")
#' use intermediate object
sce_valid = sce_tcells

#' perform FlowSOM clustering
set.seed( 42 )

sce_valid = cluster(sce_valid,
                    features = "state",
                    xdim = 12,
                    ydim = 12,
                    maxK = meta, # defined above
                    seed = 42,
                    verbose = TRUE )

#' Print flowsom result
message("Printing cluster/antigen heatmap from flowsom")
pdf("~/tmp/flowsom_state_valid.pdf", width=11.7, height=8.3)
    
print(
    
        plotExprHeatmap(sce_valid,
        features = "state",
        scale = "last",
        by = "cluster_id",
        k = k,
        row_anno = FALSE,
        hm_pal = brewer.pal(n=9,name="YlOrBr"),
        bars = TRUE,
        perc = TRUE
        )
    
	)
    
dev.off()
message("Done\n")

#' Draw dotplots from df_pour
message("Printing dotplot of abundance of state metaclusters by type metacluster")

#' Get a dataframe with n events of functional metaclusters
df = table(sce_valid$type_mk,
           cluster_ids(sce_valid, k) )
#' compute % of functional metaclusters in each type metaclusters
df_pour =  as.data.frame.matrix( prop.table(df , 1) * 100 )

#' Get type metaclusters annotations
annotations = read_excel("~/Git/azimutblood/metadata/mk_id55final.xlsx")
annotations$mk_id = paste0("type_",annotations$mk_id) # use the same nomenclature

## format the dataframe to be able to plot the results
df_pour$typemk = row.names(df_pour)
df_melt = melt(df_pour, id.vars = "typemk" )
df_melt$variable = paste0("state",df_melt$variable)
df_melt$typemk_annot = NA

## loop to rename type metaclusters with annotation
for(i in 1:nrow(df_melt) ) {
    type = df_melt[ i , ]$typemk
    line_i = which( annotations$mk_id == type )   
    df_melt[ i , ]$typemk_annot = paste0(type, "_", annotations[ line_i , "merge3"] )
}

## order typemk_annot accordingly to heatmap result and typemk according to cell populations

df_melt$state = factor(df_melt$variable,  levels = c("state20",
                                                     "state18",
                                                     "state17",
                                                     "state21",
                                                     "state24",
                                                     "state22",
                                                     "state25",
                                                     "state15",
                                                     "state16",
                                                     "state9",
                                                     "state14",
                                                     "state19",
                                                     "state10",
                                                     "state11",
                                                     "state23",
                                                     "state4",
                                                     "state8",
                                                     "state6",
                                                     "state7",
                                                     "state1",
                                                     "state5",
                                                     "state2",
                                                     "state12",
                                                     "state3",
                                                     "state13") )

df_melt$typemk_annot = factor(df_melt$typemk_annot, levels = c("type_7_Tregs",
                                                               "type_3_Tregs",
                                                               
                                                               "type_1_Naive CD4+ T cells",
                                                               "type_8_CM CD4+ T cells",
                                                               "type_4_CM CD4+ T cells",
                                                               "type_2_CM CD4+ T cells",
                                                               "type_15_CM CD4+ T cells",
                                                               "type_13_CM CD4+ T cells",
                                                               "type_11_CM CD4+ T cells",
                                                               "type_9_EM CD4+ T cells",
                                                               "type_14_EM CD4+ T cells",
                                                               "type_12_EM CD4+ T cells",
                                                               "type_10_EM CD4+ T cells",

                                                               "type_30_Naive CD8+ T cells",
                                                               "type_36_CM CD8+ T cells",
                                                               "type_29_CM CD8+ T cells",
                                                               "type_28_CM CD8+ T cells",
                                                               "type_17_CM CD8+ T cells",
                                                               "type_43_EM CD8+ T cells",
                                                               "type_26_EM CD8+ T cells",
                                                               "type_24_EM CD8+ T cells",
                                                               "type_47_EMRA CD8+ T cells",
                                                               "type_27_EMRA CD8+ T cells",

                                                               "type_22_SCM DN T cells",
                                                               "type_51_Naive DN T cells",
                                                               "type_21_CM DN T cells",
                                                               "type_48_EMRA DN T cells",

                                                               "type_20_Other NC T cells",
                                                               "type_16_Other NC T cells",
                                                               "type_19_MAIT") )

## Get the dot plot with % state markers by type markers
dotplot = ggplot(df_melt, aes(x = state , y = typemk_annot, size = value, color = value ) ) +
    geom_point() +
    theme_minimal()+
    guides(color = guide_legend(order=1),
           size = guide_legend(order=2)   ) +
    theme(legend.title = element_blank(),
          axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          axis.text.x = element_text( color="black", 
                                     size=10, angle=45),
          axis.text.y = element_text(  color="black", 
                                     size=10, angle=0) )+
    scale_x_discrete(position = "top") +
    scale_colour_gradient2(low = "#ffeda0", mid = "#feb24c", high = "#f03b20")

## print dopplot with %state cells / type metaclusters
pdf("~/tmp/dotplot_state_valid.pdf", width=11.7, height=8.3)
print(dotplot)
dev.off()

#' generate plots and print in .pdf
message("Starting scater plot extraction")

#' get the name of metaclusters
mk = unique( cluster_ids(sce_valid, k ) )

plot_i = list()
all_plots = list()

for ( i in 1:meta ) {

    ## print info
    pourc = round(i/meta,2)*100
    message("Generating plots: ",pourc,"%")
    
    ## get the SCE object with only the mk data
    mk_i = list( i ) # cluster_id must be a list even with 1 mk
    sce_i = filterSCE( sce_valid, cluster_id %in% mk_i , k = k )

    ## loop to generate dotplots
    for ( j in 1:length( ch_all ) ) {

        ## get the dotplot iteration
        ch_j  = ch_all[[ j ]]
        plot_j = plotScatter( sce_i , ch_j )

        ## store the plot_j object
        plot_i[[ j ]] = plot_j

        rm(plot_j)

    }

    ## generate the title
    tit_i = paste0("meta_state",i)
    title_i = ggdraw() + 
        draw_label( tit_i , fontface = 'bold',x = 0, hjust = 0 ) +
        theme( plot.margin = margin(0, 0, 0, 7) ) # add margin on the left of the drawing canvas, so title is aligned with left edge of first plot

    ## generate the cowplot with all dotplots and store it in a list

    path_i = paste0("~/tmp/scatter_flowsom","_meta_state_", i,".pdf" )

    pdf(path_i, width = 8.3, height = 11.7)
    
    print (  cowplot::plot_grid(title_i, plotlist = plot_i)   )

    dev.off()
}

message("Done\n")

#' run diffusion map in T cell functional SCE object

sce_valid = runDR(sce_valid,
                  dr = "DiffusionMap",
                  cells = 200,
                  features = "state")

## print diffusion map according to metaclusters

plot = plotDR(sce_valid, dr = "DiffusionMap", color_by = k)
pdf("~/tmp/tcellfunc_diffmap_res.pdf", width=11.7, height=8.3)
print(plot)
dev.off()
rm(plot)

# Saving SCE object

message("Saving SCE object")

saveRDS(sce_valid, file="~/R_output/sce_objects/sce_tcellsfunc.RData")

message("Done")
