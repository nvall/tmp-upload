#' Functionnal FlowSOM validation script
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(CATALYST)
library(reshape)
library(RColorBrewer)
library(readxl)
library(flowCore)
library(SingleCellExperiment)
library(ggplot2)

#' Script performs a FlowSOM clustering with choosen number of metaclusters
#' Then draw a dotplots to compare abundances of state clusters among type clusters

#' Get the SCE object with T cells only and reallocated state markers that were also used for type identification (eg. PD1, Tbet)
source("~/Git/azimutblood/scripts/cytof_tcellfunc/cytof_func_prep_sce_tcells.R")

#' perform a screening of metaclusters with state markers
print("starting FlowSOM screening")
metaK = c(7, 10, 12, 15, 17, 20, 25, 30)  # numbers of metaK to screen 
meta = "meta"

for (i in 1:length(metaK) ) {

    #' n metaK to test
    metai = as.numeric( metaK[i] )
    #' name metaK 
    metaKi = as.character ( paste0( meta, metai ) ) 
    #' link to save output
    linki = paste0( "~/R_output/figures/",metaKi,"_function.pdf" ) 
    
    message("starting FlowSOM with n=", metai, " metaclusters ", "(",i,"/",length(metaK)," to test)" )
    
    # Load the SCE file
    message("reading sce")
    sce_mkscreen = sce_tcells
    
    # FLOWSOM clustering ----
    message("starting clustering")
    
    set.seed( 42 )
    sce_mkscreen = cluster(sce_mkscreen,
                           features = "state",
                           xdim = 12,
                           ydim = 12,
                           maxK = metai,
                           seed = 42,
                           verbose = TRUE )
        
    #' Get a dataframe with n events of functional metaclusters
    df = table(sce_mkscreen$type_55mk,
               cluster_ids(sce_mkscreen, metaKi) )
    df_nevent = as.data.frame.matrix( df ) # transform in a dataframe

    #' compute % of functional metaclusters in each type metaclusters
    df_pour =  as.data.frame.matrix( prop.table(df , 1) * 100 )

    #' Get type metaclusters annotations
    annotations = read_excel("~/Git/azimutblood/metadata/mk_id55final.xlsx")
    annotations$mk_id = paste0("typemk",annotations$mk_id) # use the same nomenclature

    #' Draw dotplots from df_pour
    ## format the dataframe to be able to plot the results
    df_pour$typemk = row.names(df_pour)
    df_melt = melt(df_pour, id.vars = "typemk" )
    df_melt$variable = paste0("state",df_melt$variable)
    df_melt$typemk_annot = NA

    ## loop to rename type metaclusters with annotation
    for(i in 1:nrow(df_melt) ) {
        type = df_melt[ i , ]$typemk
        line_i = which( annotations$mk_id == type )   
        df_melt[ i , ]$typemk_annot = paste0(type, "_", annotations[ line_i , "merge3"] )
    }

    #' Get the dot plot with % state markers by type markers
    dotplot = ggplot(df_melt, aes(x = variable , y = typemk_annot, size = value, color = value ) ) +
        geom_point() +
        theme_minimal()+
        guides(color = guide_legend(order=1),
               size = guide_legend(order=2)   ) +
        theme(legend.title = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y = element_blank(),
              axis.text.x = element_text( color="black", 
                                         size=10, angle=45),
              axis.text.y = element_text(  color="black", 
                                         size=10, angle=0) )+
        scale_x_discrete(position = "top") +
        scale_colour_gradient2(low = "#ffeda0", mid = "#feb24c", high = "#f03b20")

    #' print FLOWSOM ----
    message("print pdf result")
    pdf(linki, width=11.7, height=8.3)

    ## print heatmap of antigen and state metaclusters
    print(
        plotExprHeatmap( sce_mkscreen,
                        features = "state",
                        scale = "last",
                        by = "cluster_id",
                        k = metaKi,
                        row_anno = TRUE,
                        hm_pal = brewer.pal(n=9,name="YlGnBu"),
                        bars = TRUE,
                        perc = TRUE )
    )

    ## print dopplot with %state cells / type metaclusters
    print(dotplot)
    
    dev.off()
    message("done\n")
    
}

#' remove temporary objects
rm(metaK, df, df_pour, df_nevent, i, sce_mkscreen, linki, metai, metaKi)
