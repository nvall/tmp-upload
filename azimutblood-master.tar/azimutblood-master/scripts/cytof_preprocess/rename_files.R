# rename files automatically
# Project AZIMUT
# Nicolas Vallet

# This script is to reproduce the procedure to rename files according to group and sample_id used in this project

# require 
library(readxl)
library(tidyr)
library(dplyr)

# set working directory
setwd("~/AZIMUT/CyTOF/202010_final/")

# read metadata file with sample info
md = read_excel("metadata/metadata_sample.xlsx")
md$sample_id = factor(md$sample_id)
md$group = factor(md$group)

# get file names of the directory with file to rename
# and create a dataframe with sample names and dates
file_name = data.frame ( list.files("~/AZIMUT/CyTOF/202010_finalfiles_v2/") ) # names of files to rename
colnames(file_name) = "file_name"
file_name$file_name = factor(file_name$file_name)

file_name[, c(2,3)] = file_name %>% separate(file_name, c("acquisition_dat", "sample_id")) # allow to recover the corresponding sample name

# merge datasets
metadata = full_join(md, file_name,by="sample_id")

# remove row of samples without a corresponding file
nofile = which(is.na(metadata$file_name)) 
metadata = metadata[ -nofile , ]
rm(nofile)

# save complete metadata with file names
write.csv2(metadata, "~/AZIMUT/CyTOF/202010_finalfiles_v2/metadata_rename.csv")

# for loop to rename files

setwd(dir = "~/AZIMUT/CyTOF/202010_finalfiles_v2/") # set wd where files should be renamed

for (i in 1: nrow(file_name) ) {
  name_i = as.character( file_name[i,1] ) # get name of the file to rename
  file_i = which (metadata$file_name == name_i) # get the corresponding row of this file in the metadata dataset
  rename = paste( metadata[file_i ,]$group, "_" , metadata[file_i, ]$sample_id, ".fcs",
                  sep="") # create the new name with group and sample_if
  
  file.rename(name_i,
              rename) # rename the file
  }

rm(i,file_i,name_i,rename)
