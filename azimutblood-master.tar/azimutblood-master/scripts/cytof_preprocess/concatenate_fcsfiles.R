# Script for CyTOF .fcs files concatenation
# Project AZIMUT
# Nicolas Vallet

# this script is to reproduce .fcs files concatenation procedure with premessa package

# load required package
library(premessa)

# transfer normalized files to concatenate in one directory for each files
# set your working directory in the parent directory

setwd(dir = "~/AZIMUT/CyTOF/202010_final/AZIMUT_CyTOF_concat/")

# BEFORE RUNNING CODE
# change the directories' names as require for your normalization
# choose a file name of the concatenate files
# run the following lines

# HD6
concatenate_fcs_files(files.list=c("HD6/20200813_HD6_01_normalized.fcs",
                                   "HD6/20200813_HD6_02_normalized.fcs"
                                   ),
                      output.file = "concat/20200813_HD6_conca_normalized.fcs")


# HD11 ----
concatenate_fcs_files(files.list=c("HD11/20200930_HD11_02_normalized.fcs",
                                   "HD11/20200930_HD11_03_normalized.fcs",
                                   "HD11/20201001_HD11_02_normalized.fcs"),
                      output.file = "concat/20200930_HD11_conca_normalized.fcs")

# R1701 ----
concatenate_fcs_files(files.list=c("R1701/20200903_R1701_03_normalized.fcs",
                                   "R1701/20200903_R1701_04_normalized.fcs"),
                      output.file = "concat/20200903_R1701_conca_normalized.fcs")

# R1917 ----
concatenate_fcs_files(files.list=c("R1917/20200825_R1917_01_normalized.fcs",
                                   "R1917/20200826_R1917_02_normalized.fcs"),
                      output.file = "concat/20200826_R1917_conca_normalized.fcs")

# R1927 ----
concatenate_fcs_files(files.list=c("R1927/20200827_R1927_01_normalized.fcs",
                                   "R1927/20200827_R1927_02_normalized.fcs"),
                      output.file = "concat/20200827_R1927_conca_normalized.fcs")

# R2315 ----
concatenate_fcs_files(files.list=c("R2315/20200828_R2315_01_normalized.fcs",
                                   "R2315/20200828_R2315_02_normalized.fcs"),
                      output.file = "concat/20200828_R2315_conca_normalized.fcs")

# R2401 ----
concatenate_fcs_files(files.list=c("R2401/20200828_R2401_01_normalized.fcs",
                                   "R2401/20200828_R2401_02_normalized.fcs"),
                      output.file = "concat/20200828_R2401_conca_normalized.fcs")

# R2657 ----
concatenate_fcs_files(files.list=c("R2657/20200930_R2657_02_normalized.fcs",
                                   "R2657/20200930_R2657_03_normalized.fcs"),
                      output.file = "concat/20200930_R2657_conca_normalized.fcs")

# R2684 ----
concatenate_fcs_files(files.list=c("R2684/20200930_R2684_01_normalized.fcs",
                                   "R2684/20200930_R2684_02_normalized.fcs"),
                      output.file = "concat/20200930_R2684_conca_normalized.fcs")

# R3074 ----
concatenate_fcs_files(files.list=c("R3074/20200814_R3074_01_normalized.fcs",
                                   "R3074/20200814_R3074_02_normalized.fcs"),
                      output.file = "concat/20200814_R3074_conca_normalized.fcs")

# R3283 ----
concatenate_fcs_files(files.list=c("R3283/20200831_R3283_01_normalized.fcs",
                                   "R3283/20200831_R3283_OK_02_normalized.fcs"),
                      output.file = "concat/20200831_R3283_conca_normalized.fcs")

# R3323 ----
concatenate_fcs_files(files.list=c("R3323/20200703_R3323_01_normalized.fcs",
                                   "R3323/20200703_R3323_02_normalized.fcs"),
                      output.file = "concat/20200703_R3323_conca_normalized.fcs")

# R3335 ----
concatenate_fcs_files(files.list=c("R3335/20200716_R3335_04_normalized.fcs",
                                   "R3335/20200716_R3335_05_normalized.fcs"),
                      output.file = "concat/20200716_R3335_conca_normalized.fcs")

# R3562 ----
concatenate_fcs_files(files.list=c("R3562/20200720_R3562_01_normalized.fcs",
                                   "R3562/20200720_R3562_02_normalized.fcs"),
                      output.file = "concat/20200720_R3562_conca_normalized.fcs")

# R3753 ----
concatenate_fcs_files(files.list=c("R3753/20200610_R3753_01_normalized.fcs",
                                   "R3753/20200610_R3753_02_normalized.fcs"),
                      output.file = "concat/20200610_R3753_conca_normalized.fcs")
