## Prepare dataframe as inputs for PCA analyses scripts
## Project: AZIMUT
## Author: Nicolas Vallet

## Require
library(readxl)

## inputs

### dataframe with relative abundances of metaclusters in 
dfabund = read.csv("~/Git/azimutblood/data/cytof/mk_id_all.csv",
                   check.names = FALSE,
                   row.names = 1 )

dfmean =  read.csv("~/Git/azimutblood/data/cytof/sce_mean.csv",
                   check.names = FALSE,
                   row.names = 1 )

dfmed =  read.csv("~/Git/azimutblood/data/cytof/sce_med.csv",
                   check.names = FALSE,
                   row.names = 1 )

### dataframe with batch effects
batch = read.csv2("~/Git/azimutblood/metadata/metadata_batch.csv",
                  row.names = 2)
batch$batch = factor(batch$batch)

source("~/Git/azimutblood/scripts/datamanagement/clinical.R") # import preprocessed clinical data as a data.frame called 'md' 

batch = merge(batch, md[ , c("diagnosis", "group", "rel12", "relapse", "agvhd") ] , by = 0)

row.names(batch) = batch$Row.names
batch = batch [, -1]

### order batch by date
batch$batch = factor(batch$batch, levels = c("02/06/2020",
                                              "10/06/2020",
                                              "11/06/2020",
                                              "23/06/2020",
                                              "24/06/2020",
                                              "25/06/2020",
                                              "30/06/2020",
                                              "01/07/2020",
                                              "02/07/2020",
                                              "07/07/2020",
                                              "08/07/2020",
                                              "13/07/2020",
                                              "15/07/2020",
                                              "16/07/2020",
                                              "05/08/2020",
                                              "06/08/2020",
                                              "10/08/2020",
                                              "11/08/2020",
                                              "12/08/2020",
                                              "13/08/2020",
                                              "17/08/2020",
                                              "18/08/2020",
                                              "15/09/2020",
                                             "17/09/2020"))

### get factor variables as factor and in relapse, death = CR
batch$relapse = factor(batch$relapse, labels = c("CR","REL","CR") )
batch$agvhd = factor(batch$agvhd, labels = c("noGVHD", "aGVHD", "noGVHD") )
batch$diagnosis = factor(batch$diagnosis)

## merge 2 dataframes

mergabun = merge(dfabund, batch, by = 0)

mergmean = merge(dfmean, batch, by = 0)

mergmed  = merge(dfmed, batch, by = 0)

rm(batch, md, dfabund, dfmean, dfmed)

message( "\nmergabun = DF with relative abundance of mk \n\nmergmean = Arcsin transformed mean values of marker \n \nmergmed = Arcsin transformed median values of markers")
