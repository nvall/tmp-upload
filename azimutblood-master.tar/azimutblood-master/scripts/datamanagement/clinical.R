#' Datamanagement of clinical metadata: prepare DF 
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(tidyverse)

#' load .csv file
md = read.csv2("~/Git/azimutblood/metadata/metadata_clinical.csv", row.names = 1)

#' transform to factor
fact = c("gender", "diagnosis", "diagnosis2", "diag_other", "group")
for(i in 1:length( fact ) ) {
    col =  which( colnames( md ) == fact[i] )
    md[ , col] = factor( md[ , col] )
}
rm(col, i, fact)

#' transform age in numeric
md$age = as.numeric(md$age)

#' remove unused columns
col = which( colnames( md ) == "diag_other" )
md = md[, -col]
rm(col)

#' define dates columns
dat = grep( "dat_", colnames( md ), fixed = TRUE) 
for (i in 1:length( dat ) )  {
    col =  dat[i]
    md[ , col ] = as.Date( md[, col ], "%d/%m/%Y" )
}

rm(dat, i, col)

#' compute time differences
md$del_relapse = ifelse( md$relapse == 1, (md$dat_relapse - md$dat_hsct)/30, (md$dat_lfu - md$dat_hsct)/30 )
md$del_agvhd = ifelse( md$agvhd == 1, (md$dat_agvhd - md$dat_hsct), (md$dat_lfu - md$dat_hsct) )

#' label levels of agvhd and relapse
md$relapse = factor(md$relapse, levels = c(0,1,2), labels = c("Censored", "Relapse", "Death") )
md$agvhd = factor(md$agvhd, levels = c(0,1,2), labels = c("Censored", "Relapse", "Death") )

#' create a variable rel12 with patients who relapsed in the 12 first months 
md$rel12 = NA 
md[ (md$group != "HD" & md$relapse == "Relapse" & md$del_relapse <= 12) , "rel12" ] = "REL12" # patients who relapsed before 12 months are REL12
md[ (md$group != "HD" & md$del_relapse > 12 & is.na(md$del_relapse)==FALSE ), "rel12" ] = "CR12" # here a del_relapse > 12 is mandatory to confirm the absence of relapse in the first 12 months, then del_relapse must not be NA

#' message to confirm the script is done
message("Clinical metadata imported and preprocessed\nDone")
