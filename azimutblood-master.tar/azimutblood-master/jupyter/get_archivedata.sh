# this script create a tar file with all data files needed to run jupyter notebooks from the git repository
# Project : AZIMUT
# Author : Nicolas Vallet

