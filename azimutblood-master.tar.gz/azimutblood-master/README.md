# AZIMUT Blood repository

This repository aims at storing scripts and databases used in AZIMUT project blood analyses

## Purpose
This repository aims at sharing scripts and anonymized databases to reproduce results.

## Repository organization

### data

Contains files with data (from CyTOF assays, metabolomics, etc.) to perform analyses.

### guixconfig

Contains files to load GUIX session in Ubuntu.

### metadata

Contains metadata files which are used in scripts.

### scripts

Contains all scripts ordered according to steps of the analysis.

## Any query?
Feel free to contact Nicolas : nicolas.vallet@inserm.fr
