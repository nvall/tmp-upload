## Draw scatterplots to check FlowSOM metaclusters annotations
## Project AZIMUT
## Nicolas Vallet

## require
library(CATALYST)
library(scater)
library(cowplot)
library(readxl)

## inputs
### sce objects
message("Reading SCE object")

sce = readRDS( file = "~/R_output/sce_objects/sce_all_clustmerg.RData" )

message("Done \n")

## get the number of metaclusters to check
message("Reading metadata and defining dotplots")

mk = unique( cluster_ids(sce, "meta55" ) )

k = "meta55"

## get the merging parameters
merging = read_excel("~/metadata/mk_id55final.xlsx")
merging = as.data.frame(merging)

## define dotplots
ch_all = list(c( "CD3" , "CD45" ),
              c( "CD8" , "CD4" ) ,
              c( "CD45RA" , "CD27" ),
              c( "CD45RA" , "CD95" ),
              c( "CD45RA" , "CCR7" ),
              c( "CD25" , "CD127" ),
              c( "CXCR3" , "CCR4" ),
              c( "CD161" , "CCR5" ),
              c( "CXCR5" , "CCR4" ),
              c( "CD95" , "HLA-DR" ),
              c( "TCR_Va7.2" , "CD161" ),
              c( "CD3" , "CD56" ),
              c( "CD19" , "HLA-DR" ),
              c( "CD19" , "CD27" ),
              c( "CD38" , "CD24" ),
              c( "IgD" , "IgM" ),
              c( "CD20" , "CD38" ),
              c( "CD56" , "HLA-DR" ),
              c( "CD56" , "CD16" ),
              c( "CD14" , "CD16" )
              )

message("Done \n")

## generate plots and print in .pdf

message("Starting plot extraction")

plot_i = list()
all_plots = list()

for ( i in 1:55 ) {

    ## print info
    pourc = round(i/length(mk),2)*100
    message("Generating plots: ",pourc,"%")
    
    ## get the mk annotation
    annot_i = merging[i , 4]

    ## get the SCE object with only the mk data
    mk_i = list( i ) # cluster_id must be a list even with 1 mk
    sce_i = filterSCE( sce, cluster_id %in% mk_i , k = k )

    ## loop to generate dotplots
    for ( j in 1:length( ch_all ) ) {

        ## get the dotplot iteration
        ch_j  = ch_all[[ j ]]
        plot_j = plotScatter( sce_i , ch_j )

        ## store the plot_j object
        plot_i[[ j ]] = plot_j

        rm(plot_j)

    }

    ## generate the title
    tit_i = paste0("meta",i ," " ,annot_i )
    title_i = ggdraw() + 
        draw_label( tit_i , fontface = 'bold',x = 0, hjust = 0 ) +
        theme( plot.margin = margin(0, 0, 0, 7) ) # add margin on the left of the drawing canvas, so title is aligned with left edge of first plot

    ## generate the cowplot with all dotplots and store it in a list

    path_i = paste0("~/R_output/figures/scatter_flowsom","_meta", i,".pdf" )

    pdf(path_i, width = 8.3, height = 11.7)
    
    print (  cowplot::plot_grid(title_i, plotlist = plot_i)   )

    dev.off()
}



message("Done")
