# CyTOF IMPORT DATA
# Project AZIMUT
# Nicolas Vallet

# This script aims at creating a SCE object from .fcs files
# SCE object is then saved as sce_allcells.RData file and can be opened from any computer

# REF : https://www.bioconductor.org/packages/release/workflows/vignettes/cytofWorkflow/inst/doc/cytofWorkflow.html

# require
message("loading packages")
library(CATALYST)
library(readxl)
library(flowCore)

# set the working directory which contains 1/.fcs files 2/panel metadata 3/files metadata

setwd("~/cytof_files")

# read .fcs files metadata 
## /!!\ MAKE SURE THAT at least col names : file_name sample_id condition and patient_id are present even if empty
md = read_excel("metadata_files.xlsx")
print ( head( data.frame(md) ) )

# read .fcs files
fs = read.flowSet(files = md$file_name ) # wait it might take (5 to 10 minutes)

# read .fcs channels metadata
panel = read_excel("metadata_panel.xlsx")
print ( head(data.frame(panel) ) )

# prepare the SingleCellExperiment (SCE) object
# * first specify levels for conditions to assure desired ordering
md$file_name  = factor(md$file_name)
md$condition  = factor(md$condition, levels=c("AZM","PLA","HD") )
md$sample_id  = factor(md$sample_id)
md$patient_id = factor(md$patient_id)

# * construct the SCE object: may take some time 10 - 15 min
sce = prepData(fs, panel, md, features = panel$fcs_colname)

# remove fs to save memory space
rm(fs)

saveRDS(sce, file="~/R_output/sce_objects/sce_allcells.RData")

print("done")
