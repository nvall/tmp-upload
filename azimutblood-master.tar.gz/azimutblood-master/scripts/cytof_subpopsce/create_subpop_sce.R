#' Create subpopulation SCE objects from full length SCE
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' 1/ this script aims at creating subpopulation SCE objects
#' 2/ print phenotype marker heatmaps
#' 3/ perform UMAP dimension reduction
#' 4/ save the SCE object to be used for downstream analyses
#' 5/ extract relative abundance within subpop

#' Require
library(CATALYST)
library(readxl)

#' remove scientific notation of decimals
options(scipen = 999)

#' create a list of subpop SCE
list_sce = c("T cells", "NK cells", "B cells", "Myeloid")
list_name_sce = c("tcells", "nkcells", "bcells", "myeloid")
mat_sce = data.frame( cbind(list_sce, list_name_sce) )

#' load cluster annotations
cluster_annot = read_excel("~/Git/azimutblood/metadata/mk_id55final.xlsx")

#' Load SCE object
message("Reading sce")
sce = readRDS(file="~/R_output/sce_objects/sce_all_clustmerg.RData")
message("Done")

#' loop to create the sub population SCE objects

## progression message parameters
j = 1 # follow-up message start at 1
end = length(list_sce)

for( i in list_sce ) {

    #' progression messages
    message("running ", j, "/", end)
    j = j+1

    #' create path to save heatmap pdf and SCE object
    name_file = mat_sce[ mat_sce$list_sce == i , 2 ]
    pdf_path = paste0("~/tmp/heatmap_", name_file,".pdf")
    sce_path = paste0("~/tmp/sce_", name_file, ".RData")
    csv_path = paste0("~/tmp/relab_", name_file, ".csv")
    
    #' get cluster ids of subpopulation
    clust_id = which(cluster_annot$merge1 == i)

    #' filter SCE
    message("Filter SCE")
    sub_sce = filterSCE(sce, cluster_id %in% c(clust_id), k = "meta55")

    #' plot heatmap
    message("Print heatmap")
    pdf(pdf_path, width=11.7, height=8.3)
    print(
        
        plotExprHeatmap(sub_sce,
                        features = "type",
                        scale = "last",
                        by = "cluster_id",
                        k = "meta55",
                        row_anno = FALSE,
                        hm_pal = brewer.pal(n=9,name="YlGnBu"),
                        bars = TRUE,
                        perc = TRUE
                        )
        
    )
    dev.off()

    #' extract relative abundance data
    message("Extract relative abundance data")
    events = table( sub_sce$sample_id, cluster_ids( sub_sce, "meta55") )
    prop_events = prop.table(events, 1)*100
    write.csv(prop_events, csv_path)

    #' running UMAP clustering
    message("Run UMAP clustering on sub SCE")
    sub_sce <- runDR(sub_sce, dr = "UMAP", cells = 500, features = "type")

    #' saving SCE objects
    message("Saving SCE object")
    saveRDS(sub_sce, file = sce_path)
    message("Done")
    
}
