## CyTOF analysis pipeline

1. Preprocessing (cytof_preprocess)
* raw CyTOF files are normed with beads (bead_based_normalization.R)
* samples with multiple files are concatenated (concatenate_fcsfiles.R)
* cells are identified and .fcs is cleaned by manual gating on FlowJO 
* files are rename according to sample id and group AZM or PLA (rename_files.R)

2. FlowSOM clustering with CATALYST (cytof_flowsom)
* files are converted in SCE format (importfcsdata.R)
* metaclusters optimal number is chosen according to the results of metacluster screening (flowsom_screen.R)
* final FlowSOM is computed and appended to SCE object (flowsom_final.R)
* if needed metaclusters are merged (flowsom_merge.R)
* if needed check metacluster definition with scatter plots (flowsom_check_scatter.R)

3. UMAP visualisation of clustering (cytof_umap)
* UMAP are calculated, stored and exported as .pdf (cytof_getumap.R)
* Print UMAPs according to clustering markers (cytof_printumap_markers.R)

4. Creating sub sce objects of main subpopulations from all events (cytof_subpopsce)
* Get SCE objects of subpopulations
* Run UMAP dimension reduction in subpopulations SCE objects
* Print UMAPs according to clustering markers in subpopulations SCE objects

5. Analysis of T cells functionnal markers (cytof_tcellfunct)
* Prepare the T cells sce object save type metacluster info (cytof_func_prep_sce_tcells.R) 
* screen different number of state metaclusters to define optimal number of metacluster to choose (cytof_func_flowsom_screen.R)
* *TODO: save the optimal SCE object with state metaclusters*
* *TODO: script to create gates and append to SCE according to analysis of previous results*

## Extract abundance (cytof_extractdata)
* from SCE object with metaclusters and manual merging performed : extract number and abundance of cells (extabundances.R)
* extract mean, median and maximum value of antigen expression from a sce object (extmeanmarkers.R)

## Perform statistical analyses (cytof_analyses)
* univariate analysis to compare AZM and PLA patients (univ_azmpla.R)
* cumulative incidence of relapse and RR with Fine and Gray model according to metaclusters (cmprsk_all.R)
* batch effect analysis: 1/ perform PCA analysis with mean/median antigen detection ; 2/draw violin plots of each antigen detection by batch days. Mean and IQR1-IQR3 are plotted ; must enter the name of dataframe in the script to draw plots (pca_batch.R)
* perform PCA analysis only in patients data (pca_patients.R)

## Perform task to prepare datasets for analyses (datamanagment)
* prepare clinical metadata (clinical.R)
* prepare data for PCA analysis: batch, group notably (pca_prepare_df.R)
