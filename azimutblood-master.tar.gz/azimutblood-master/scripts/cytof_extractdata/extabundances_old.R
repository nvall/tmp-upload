## Extract abundance data from SCE object
## Project AZIMUT
## Nicolas Vallet 



## The purpose of this script is to extract cluster abundance from a single cell experiment object
## Return value is two dataframe with
##- first with - rows : patients - colums : number of cells in each cluster
##- second with - rows : patients - colums : percentage of cells relative to all cells and main lineages (T, CD4+, CD8+, NK, etc.)



## require
library(CATALYST)
library(SingleCellExperiment)
library(tibble)
##- a SCE object with metaclusters and manually merged clusters
##- a the excel file with merging parameters
##- a .csv file with names of Xs in rows and Ys in cols (must be the same names as in excel merging parameters file) 


## remove scientific notation of decimals
options(scipen = 999)

## get merged mk identifications 
merge = read_excel("~/metadata/mk_id55final.xlsx")

## read "inter" table with X and Y defined
inter = read.csv2(file = "~/metadata/relabextract.csv", # create a table with x = numerator and col = denominator. Compute a relative abundance (relab) table only if inter(x,y) = "y"
          header = TRUE,
          row.names = 1,
          na.strings = "")

## create a list of clustering method to export (make sure to put the metaclusters in the first position of list_clust.
list_clust = c("meta55", colnames(merge)[2:ncol(merge)] )

## create a list of samples in SCE object
list_samples = unique( sample_ids (sce) )

## create a table in which data to export will be appended
export = as.data.frame(matrix(nrow = length(list_samples), ncol = 0  ) )
rownames(export) = list_samples # in export = rows = sample_id




## extract stats from SCE object: the following loop will extract n events in each clusters from list_clust
for (i in 1:length(list_clust) ) {

    # info to follow extract status
    message("extracting events data from SCE object: ", round(i/length(list_clust),2)*100,"% (",list_clust[i],")")

    # get the variables used in loop
    clust_i = list_clust[i] # get the cluster to extract from list_clust
    table_i = table(sample_ids( sce ), # get the table in which samples_ids = row and cluster_ids = col
                    cluster_ids( sce, clust_i )  )
    table_i =  as.data.frame.matrix ( table_i ) # transform the table_i in dataframe structure

    # check for duplicates colnames (identical metacluster merging)
    dup_names = intersect(names(export), names(table_i)) # get name of duplicates between future output and input
    dup_col = which(colnames(table_i) %in%  dup_names) # get cols where duplicates are located

    # if there are duplicates ==> remove it so that they are not appended in the final output
    if (length(dup_col) != 0) {  
        table_i = table_i[, -dup_col]
    }

    # if loop to transform name of metaclusters to meta"xx" in order to get an understandable output.
    if (i == 1) { 
        colnames_orig = colnames(table_i) # get colnames from table_i
        colnames(table_i) = paste0("meta",colnames_orig) # transform table_i colnames with appended "meta" annotation
        table_i$all = rowSums( table_i ) # create a col with all events to compute abundance transformations
    }

    # end the loop with merging export i with export i-1 (obtain a complete output
    export = merge(export, table_i, by = 0, no.dups = TRUE ) # merges export with extracted table_i
    rownames(export) = export[ , 1] # set "Row.names" col as rownames of the data.frame
    export = export[ , -1] # remove "Row.names" col which is created with merge(x, by = 0) ==> EXPORT IS OK to continue with i+1
    
}
                                     
rm(dup_names, dup_col)

message("Done \n")

## Compute relative abundance results

extabund = list() # create a list to store all dataframes

### extract % all events
for(i in 1:ncol(merge) ) {

    # get name of merged cluster x
    merge_x = names( merge[i] )
    
    # get the list of x to divise
    list_x = unique ( deframe( merge[i] ) ) 

    # if metacluster id change names
    if (i == 1) {
        list_x = paste0("meta",list_x)    
        }
  
    # get % for all 
    ## get col number which 
    col_x = which( colnames(export) %in% list_x )

    ## get all n events
    col_y = which( colnames(export) == "all")

    ## create intermediate dataframe with cols needed
    relab_x = export[, col_x]

    ## compute % pop X(in group of clusters) / all cells
    relab_x = relab_x/export[, col_y]
    colnames( relab_x ) = paste0( colnames( relab_x ),"_", "all" ) 

    ## store the result
    tablename = paste0(colnames(merge)[i],"_","all")
    extabund[[tablename]] = relab_x

    }

### extract % clusters
message("Computing relative abundance results as described below")
print(inter)

i=1
j=1
k=1

for (i in 1:ncol(merge)) {

    # get name of the group of clusters in Y
    name_merge_y = names( merge[i] )

    # get merge subpop in Y
    merge_i =  unique ( deframe( merge[i] ) ) 

    for (j in 1:length(merge_i) ) {

        # get the subpop in merge_i (Y)
        subpop_j = merge_i[ j ]
        
        # get y col number from export
        col_y = which( colnames(export) == subpop_j )

        # get x rows with corresponding subpop in merge
        row_x = which( merge[ , i  ] == subpop_j )

        # get names of each X subpop and extract 
        for ( k in 1:ncol( merge ) ) {

             # check if allowed by the "inter" table
             name_merge_x = names( merge[row_x , k ] )
             if ( is.na( inter[name_merge_x, name_merge_y] ) == FALSE ) {

                 # check if X = Y : do not perform the calcul
                 if( name_merge_x != name_merge_y ) {
             
                     # get names of variables
                     names_x = unique ( deframe( merge[row_x, k ] ) )

                     if ( name_merge_x == "mk_id" ) {
                         names_x = paste0("meta",names_x)
                         }
                         
                     # get x cols names and table
                     col_x = which( colnames(export) %in%  names_x )

                     # get table with X values from export
                     relab_x = export[, col_x]

                     if ( !(col_y %in% col_x )   )  {
                         if ( is.null( ncol( relab_x ) ) == FALSE ) {
                             
                              # divise by Y
                             relab_x = relab_x / export[ , col_y]
                             colnames( relab_x ) = paste0( colnames( relab_x ),"_", subpop_j ) 

                             # store the result
                             tablename = paste0( name_merge_x , "_" , subpop_j )
                             extabund [[tablename]] = relab_x
                             
                         }                        
                     }
                 }
             }
        }
    }
}

message("Done \n")

## print table

message("Saving events numbers in .csv")

write.csv(export, "~/R_output/data/events.csv")

message("Saving output in .csv files")

for (i in 1:length( extabund ) ) {

    # info to follow extract status
    completion = round(i/length(extabund),2)*100
    if ( completion %in% seq(0,100,25) ) {
    message("writing .csv files: ", completion, "%")
    }
    
    # get name of the table
    nametable = names(extabund[ i ] )
    
    # define file path
    path_i = paste0("~/R_output/data/",nametable,".csv")

    # get the df to save
    savedf = extabund [[ i ]]

    # save df in path_i
    write.csv(savedf, path_i)

}


message("Done \n")

## removing intermediate variables without removing SCE object
remove = ls()
pos_sce = which (remove == "sce")
remove = remove[ -pos_sce ]
rm( list = remove )
rm( remove )

## Ending message to check which clusters were exported
message("End of the script")
