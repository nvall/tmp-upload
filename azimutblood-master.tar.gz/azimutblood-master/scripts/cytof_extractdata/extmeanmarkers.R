## Script to extract mean and median values of markers from SCE object
## Project: AZIMUT
## Author: Nicolas Vallet

## checked with several samples with FlowJO statistics. Extracted data are arcsin transformed. To check, take 1 .fcs files, read with FlowJO and export statistic (eg: x ). Then in Excel calculate =asin( x / 5). Minor differences but consistent.
## also check with HelenaLC methods https://github.com/HelenaLC/CATALYST/issues/182

## Require
library(CATALYST)

## remove scientific notation of decimals
options(scipen = 999)

## read SCE object

message("Reading sce")
    
sce = readRDS(file="~/R_output/sce_objects/sce_all_clustmerg.RData")

message("Done")

## identify markers to export
markers_id = (rowData(sce)$marker_name)
n_marker = length( unique(markers_id) )

message("markers to export")
print(markers_id)

## identify patients events according to patient id
sample_id = colData(sce)$sample_id
uniq_sample_id = unique(sample_id)
n_sample = length( uniq_sample_id )

message("sample id")
print(unique (sample_id ) )

## create a dataframe with events in columns and all markers in row
marker_vals = as.data.frame( as.matrix( assays( sce )[[ "exprs" ]] ) )

marker_vals = t( marker_vals )

marker_vals = as.data.frame( marker_vals )

marker_vals$sample_id = sample_id

## create the output data.frame : rows = "sample_id" and columns "markers")
sce_mean = as.data.frame( matrix( nrow = n_sample, ncol = n_marker ) )
row.names(sce_mean) = unique(sample_id)
colnames(sce_mean) = unique(markers_id)

sce_median = as.data.frame( matrix( nrow = n_sample, ncol = n_marker ) )
row.names(sce_median) = unique(sample_id)
colnames(sce_median) = unique(markers_id)

sce_max = as.data.frame( matrix( nrow = n_sample, ncol = n_marker ) )
row.names(sce_max) = unique(sample_id)
colnames(sce_max) = unique(markers_id)


sce_mode = as.data.frame( matrix( nrow = n_sample, ncol = n_marker ) )
row.names(sce_mode) = unique(sample_id)
colnames(sce_mode) = unique(markers_id)


## start a loop to get the results by searching sample_id in rows
for( i in 1:nrow( sce_mean ) ) {

    message("Extracting data from sample ", i,"/",nrow(sce_mean) )
    
    ## get sample_id
    sample_i = row.names(sce_mean)[i]

    ## dataframe is subseted with the sample_id of interest only (i)
    df_i = subset( marker_vals, sample_id == sample_i ) 
    
    ## start a loop to get means and median of columns by sample_id
    for (col in 1:n_marker ) {

        ## check if colnames in the original and final datasets are the same
        if( colnames( sce_mean[ col ] ) != colnames( marker_vals [col] ) ) {

            message("colnames of sce_mean and marker_vals are not the same")
            
        } else {

            sce_mean[ i , col ]  = mean( df_i [ , col] )

            sce_median[ i, col ] = median( df_i[ , col] )

            sce_max[ i , col ]   = max( df_i[, col] )

        }
    }
}

## write csv files
write.csv(sce_mean, "~/R_ouput/reports/sce_mean.csv")

write.csv(sce_median, "~/R_ouput/reports/sce_med.csv")

write.csv(sce_max, "~/R_ouput/reports/sce_max.csv")

message("\nDone")
