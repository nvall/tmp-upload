#' Script to prepare SCE object to be used for T cells functionnal analysis
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(CATALYST)
library(readxl)
library(flowCore)

#' Input: a SCE object with FlowSOM and merged clusters
message("Reading sce")    
sce = readRDS(file="~/R_output/sce_objects/sce_all_clustmergumap.RData")
message("Done")

#' save TYPE metacluster names
message("\ntype metaclusters identification by cells are stored in 'type_mk' use sce$type_mk to access")
sce$type_mk = paste0("type_", cluster_ids(sce, "meta55") )

#' Get table with metaclusters annotations
mk_annotation = read_excel("~/Git/azimutblood/metadata/mk_id55final.xlsx")
mk_annotation = as.data.frame(mk_annotation)                     

#' keep only a subset of clusters with T cells
tcells_clust = which( mk_annotation$merge1 == "T cells") # get the T cells corresponding meta55 ids
sce_tcells = filterSCE( sce, cluster_id %in% tcells_clust, k = "meta55" ) # filter SCE according to T cells ids

#' change PD-1 as a state marker
message("\nre-allocating PD-1 and Tbet as state markers")
rowData(sce_tcells)[ "PD-1", 3 ] = "state"
rowData(sce_tcells)[ "Tbet", 3 ] = "state"

rm(tcells_clust, mk_annotation )

message("\new sce object created: 'sce_tcells'")
