#' Compute correlation between mk_id and draw heatmap/networks
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Require
library(corrplot)
library(ggplot2)
library(RColorBrewer)
library(igraph)

#' Load dataframe with mk_id abundance
df_mkid = read.csv("~/Git/azimutblood/data/cytof/mk_id_all.csv",
                   row.names = 1)

#' Load clinical metadata
source("~/Git/azimutblood/scripts/datamanagement/clinical.R")

AZM = row.names(md[ md$group == "AZM", ] )
PLA = row.names(md[ md$group == "PLA", ] )

df_mkid_azm = df_mkid[ row.names(df_mkid) %in% AZM, ] 
df_mkid_pla = df_mkid[ row.names(df_mkid) %in% PLA, ]

#' Compute the correlation matrice
mat_mkid = cor(df_mkid)
mat_mkid_azm = cor(df_mkid_azm)
mat_mkid_pla = cor(df_mkid_pla)

#' corrplot 
mat_plot = corrplot(mat_mkid,
                    method = "circle",
                    order = "hclust",
                    col = brewer.pal(n=11, name = "RdBu")
                    )


mat_plot_pla = corrplot(mat_mkid_pla,
                    method = "circle",
                    order = "hclust",
                    col = brewer.pal(n=11, name = "RdBu")
                    )

mat_plot_azm = corrplot(mat_mkid_azm,
                    method = "circle",
                    order = "hclust",
                    col = brewer.pal(n=11, name = "RdBu")
                    )

mat_net = mat_mkid_azm
mat_net[mat_net<0.4 ] = 0

network <- graph_from_adjacency_matrix( mat_net, weighted=T, mode="undirected", diag=F)

net = plot(network)
           
           #'=== vertex
           vertex.color = "blue",          # Node color
           vertex.frame.color = "white",                 # Node border color
           vertex.shape="circle",                        # One of “none”, “circle”, “square”, “csquare”, “rectangle” “crectangle”, “vrectangle”, “pie”, “raster”, or “sphere”
           vertex.size=20,                               # Size of the node (default is 15)
           vertex.size2=NA,                              # The second size of the node (e.g. for a rectangle)

           #' === vertex label
           #vertex.label=,                   # Character vector used to label the nodes
           vertex.label.color="black",
           vertex.label.family="Helvetica",                  # Font family of the label (e.g.“Times”, “Helvetica”)
           vertex.label.font=1,                          # Font: 1 plain, 2 bold, 3, italic, 4 bold italic, 5 symbol
           vertex.label.cex=1,                           # Font size (multiplication factor, device-dependent)
           vertex.label.dist=0,                          # Distance between the label and the vertex
           vertex.label.degree=0 ,                       # The position of the label in relation to the vertex (use pi)

           #' === Edge
           edge.color="black",                           # Edge color
           edge.width = mat_net,                                 # Edge width, defaults to 1
           edge.arrow.size = 1,                            # Arrow size, defaults to 1
           edge.arrow.width = 1,                           # Arrow width, defaults to 1
           edge.lty="solid",                             # Line type, could be 0 or “blank”, 1 or “solid”, 2 or “dashed”, 3 or “dotted”, 4 or “dotdash”, 5 or “longdash”, 6 or “twodash”
           edge.curved=0    ,                          # Edge curvature, range 0-1 (FALSE sets it to 0, TRUE to 0.5)
