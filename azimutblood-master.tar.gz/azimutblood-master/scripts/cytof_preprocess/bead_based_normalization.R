# Script for CyTOF beads normalization
# Project AZIMUT
# Nicolas Vallet

# This script is to reproduce bead_based_normalization used in this project

# Nolan's lab normalization tool is no longer actively supported. They recommand to use premessa

# load premessa package : https://github.com/ParkerICI/premessa // install_github("ParkerICI/premessa")
library(premessa)

# transfer all raw .fcs files to a specific directory

# start GUI
normalizer_GUI()

# a tab opens in your web browser
# before starting with web browser, select any file from your directory containing all files to normalize and click on open
# go to the opened tab
# select the first file
# gate the beads on this file following Nolan's lab bead normalization recommandations (https://github.com/nolanlab/bead-normalization/wiki/Normalizing-FCS-Files)
# apply gate to all files
# check on each batch if gate overlap with beads signals
# click on Normalize then wait
# New files will appear in the specific directory as shown here: https://github.com/ParkerICI/premessa#bead-based-normalization