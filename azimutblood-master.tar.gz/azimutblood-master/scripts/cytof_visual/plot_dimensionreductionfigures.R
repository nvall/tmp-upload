#' This script aims at plotting dimension reduction figures
#' Project: AZIMUT
#' Author: Nicolas Vallet

#' Plot DR figures in a single letter US format .pdf file with 1/ clusters id 2/ all markers position

#' Require
library(CATALYST)
library(cowplot)

#' Read SCE object
message("Reading SCE object")
sce = readRDS("~/R_output/sce_objects/sce_tcellsfunc.RData")
# sce = readRDS("~/R_output/sce_objects/sce_all_clustmergumap.RData") # all cells
# sce = readRDS("~/R_output/sce_objects/sce_tcells.RData")
# sce = readRDS("~/R_output/sce_objects/sce_bcells.RData")
# sce = readRDS("~/R_output/sce_objects/sce_nkcellsfunc.RData")
# sce = readRDS("~/R_output/sce_objects/sce_myeloid.RData")
message("Done\n")

#' Get all plots

statemk = row.names(rowData(sce)[rowData(sce)$marker_class == "state", ])

typemk  = row.names(rowData(sce)[rowData(sce)$marker_class == "type" , ])

plot = plotDR(
    sce,
    dr = "DiffusionMap",
    color_by = statemk, 
    facet_by = NULL,
    ncol = NULL,
    assay = "exprs",
    scale = TRUE,
    q = 0.01,
    a_pal = hcl.colors(10, "Viridis")
    
)


plot = plotDR(
    sce,
    dr = "UMAP",
    color_by = typemk, 
    facet_by = NULL,
    ncol = NULL,
    assay = "exprs",
    scale = TRUE,
    q = 0.01,
    a_pal = hcl.colors(10, "Viridis")
    
)


plot = plotDR(
    sce,
    dr = "UMAP",
    color_by = "meta55", 
    facet_by = NULL,
    ncol = NULL,
    assay = "exprs",
    scale = TRUE,
    q = 0.01,
    a_pal = hcl.colors(10, "Viridis")
    
)

plot = plotDR(
    sce,
    dr = "UMAP",
    color_by = "merge1",  #merge2 #merge3
    facet_by = NULL,
    ncol = NULL,
    assay = "exprs",
    scale = TRUE,
    q = 0.01,
    a_pal = hcl.colors(10, "Viridis")
    
)


#' Print figure

tiff("~/tmp/plotDR.tiff", width = 8.5, height = 11, units = "in", res = 300)
print(plot)
dev.off()

message("Done\n")
