## Circular dendogram to visualize cluster hierarchy
## Project AZIMUT
## Author: Nicolas Vallet

## source : www.r-graph-gallery.com

## Require
library(ggraph)
library(igraph)
library(tidyverse)
library(readxl)
library(RColorBrewer)

## Require
library(ggraph)
library(igraph)
library(tidyverse)
library(readxl)
library(RColorBrewer)

## inputs
### metaclusters id with merging parameters so that events < mk_id < merge3 < merge 2 < merge 1 < all
merge_table = read_excel( "~/Git/azimutblood/metadata/mk_id55final.xlsx" )
merge_table = as.data.frame( merge_table )

## get list of values in each merge groups
### set a list object to store factors
groups = list()

### loop to get each factors within each variable
for (i in 1:length( colnames(merge_table) ) ) {
  
  name_i = colnames(merge_table[ i ] )
  list_i = unique( merge_table[, i ] )
  
  groups[[name_i]] = list_i
}

## create a dataframe with hierchical structure
d1 = data.frame(from = "origin", to = groups[["merge1"]] )

d2 = data.frame(from = "", to = groups[["merge2"]] )
for (i in 1:nrow(d2) ) {
  name_to = d2[i , 2 ]
  row_from = which( merge_table[ , "merge2"] == name_to )
  name_from = unique( merge_table[ row_from, "merge1"] )
  d2 [i, 1] = name_from
}

d3 = data.frame(from = "", to =  groups[["merge3"]] )
for (i in 1:nrow(d3) ) {
  name_to = d3[i , 2 ]
  row_from = which( merge_table[ , "merge3"] == name_to )
  name_from = unique( merge_table[ row_from, "merge2"] )
  d3 [i, 1] = name_from
}

d4 = data.frame(from = "", to = groups[["mk_id"]] )
for (i in 1:nrow(d4) ) {
  name_to = d4[i , 2 ]
  row_from = which( merge_table[ , "mk_id"] == name_to )
  name_from = unique( merge_table[ row_from, "merge3"] )
  d4 [i, 1] = name_from
}

## append dataframe together in rows
edges = rbind(d1, d2, d3, d4)

## add a column with

## create a vertices dataframe. One line per object of our hierarchy
vertices = data.frame(
  name = unique(c(as.character(edges$from), as.character(edges$to))) , 
  value = 1 )

## Let's add a column with the group of each name. It will be useful later to color points
vertices$group = edges$from[ match( vertices$name, edges$to ) ]

## get the graph
mygraph = graph_from_data_frame( edges, vertices = vertices)
mygraph

dendo1 = ggraph(mygraph, layout = 'dendrogram', circular = TRUE) + 
  
  #coord_flip() +
  
  geom_edge_diagonal(colour="darkgrey") +
  
  scale_edge_colour_distiller(palette = "Paired") +
  
  geom_node_text(aes(x = x*1.15, y=y*1.15, 
                     #filter = leaf, 
                     label=name, 
                     colour=group), 
                 size=3, alpha=1) +
  
  geom_node_point(aes(filter = leaf, 
                      x = x*1.07, y=y*1.07, colour = group, size = 1, alpha=1)) +
  
  scale_colour_manual(values= rep( brewer.pal(9,"Paired") , 60) ) +
  
  scale_size_continuous( range = c(0.1,10) ) +
  theme_void() +
  theme( legend.position="none", plot.margin=unit(c(0,0,0,0),"cm")   ) +
  expand_limits(x = c(-1.3, 1.3), y = c(-1.3, 1.3))

dendo2 = ggraph(mygraph, layout = 'dendrogram', circular = TRUE) + 
  
  #coord_flip() +
  
  geom_edge_diagonal(colour="darkgrey") +
  
  scale_edge_colour_distiller(palette = "Paired") +
  
  geom_node_text(aes(x = x*1.15, y=y*1.15, 
                     filter = leaf, 
                     label=name, 
                     colour=group), 
                 size=3, alpha=1) +
  
  geom_node_point(aes(filter = leaf, 
                      x = x*1.07, y=y*1.07, colour = group, size = 1, alpha=1)) +
  
  scale_colour_manual(values= rep( brewer.pal(9,"Paired") , 60) ) +
  
  scale_size_continuous( range = c(0.1,10) ) +
  theme_void() +
  theme( legend.position="none", plot.margin=unit(c(0,0,0,0),"cm")   ) +
  expand_limits(x = c(-1.3, 1.3), y = c(-1.3, 1.3))



## save graphs in pdf 
pdf("~/tmp/circulardendo.pdf", width=8, height=8)

print(
  
  dendo1
  
)

print(
  
  dendo2
  
)

dev.off()
