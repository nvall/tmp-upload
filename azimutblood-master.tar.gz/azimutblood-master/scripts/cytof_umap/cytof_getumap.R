#' CyTOF Get UMAP from SCE object (usually after clustering and merging)
#' Project AZIMUT
#' Author: Nicolas Vallet

#' This script aims performing dimension reduction and create UMAP
#' then the SCE object is stored
#' input :
#* SCE object with FlowSOM metaclusters and manual merging

# REF : https://www.bioconductor.org/packages/release/workflows/vignettes/cytofWorkflow/inst/doc/cytofWorkflow.html

# require
library(CATALYST)
library(readxl)
library(flowCore)
library(cowplot)
library(RColorBrewer)
library(uwot)

# warning message (for metaclusters n=55)
print("!! this script must be used for n=55 metaclusters !!")

# Load SCE object

message("Reading sce")
    
sce = readRDS(file="~/R_output/sce_objects/sce_all_clustmerg.RData")

message("Done")

# Perform DR UMAP

set.seed(42)

message("Running UMAP")

sce <- runDR(sce, dr = "UMAP", cells = 500, features = "type")

message("Done")

# Check print UMAP by metaclusters and merges

message("plotting scater plots")

plotlist = list() # create a list of plot
plotlist = c("meta55","merge1","merge2","merge3") # here the mentions of plots to print
color_i = character() # input for color_by => see in plotlist = meta55, merge... etc.

allplots = NULL # plot saved in loop

for (i in 1:length(plotlist) ) {
    
    color_i = plotlist[i]
    
    plot = plotDR(sce, color_by = color_i, facet_by= NULL)
        
    allplots[[i]] = plot

}

rm(i, plot)

pdf("~/tmp/umap_res.pdf", width=11.7, height=8.3)

for (i in 1:length(allplots) ) {
    
    print(allplots[[i]])
    
}

dev.off()

message("Done")

rm(i, allplots, plotlist, color_i)

#' Saving SCE object

message("Saving SCE object")

saveRDS(sce, file="~/R_output/sce_objects/sce_all_clustmergumap.RData")

message("Done")
